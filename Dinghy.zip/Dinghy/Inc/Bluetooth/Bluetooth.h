#ifndef BLUETOOTH_H_
#define BLUETOOTH_H_

#include <vector>
#include "USARTBASE.h"
#include "tim4.h"

class Bluetooth : public USARTBase
{
public:
	virtual void Startup();
	bool EnterCommandMode();
	bool ExitCommandMode();
	bool ConnectCB();
	bool ConnectRUD();
	bool Disconnect();
	virtual void Reset();
	virtual bool Connected();

	void SetMaster();
	void SetAuth();
	void Restart();

private:
	bool WaitForReply(int length, unsigned char* reply, unsigned int timeout);
};

#endif /* BLUETOOTH_H_ */

/*
 * BTA:
 * 	RUD: 000666837F80
 */
