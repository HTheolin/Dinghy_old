#ifndef BLUETOOTH_BLUETOOTH1_H_
#define BLUETOOTH_BLUETOOTH1_H_

#include "Bluetooth\Bluetooth.h"

class Bluetooth1 : public Bluetooth
{
public:
	virtual void Startup();
	virtual void Reset();
	virtual bool Connected();
};

#endif /* BLUETOOTH_BLUETOOTH1_H_ */
