#ifndef BLUETOOTH_BLUETOOTH2_H_
#define BLUETOOTH_BLUETOOTH2_H_



#include "Bluetooth\Bluetooth.h"

class Bluetooth2 : public Bluetooth
{
public:
	virtual void Startup();
	virtual void Reset();
	virtual bool Connected();
};


#endif /* BLUETOOTH_BLUETOOTH2_H_ */
