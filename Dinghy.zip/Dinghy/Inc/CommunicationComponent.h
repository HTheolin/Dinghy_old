#ifndef HEADERS_COMMUNICATIONCOMPONENT_H_
#define HEADERS_COMMUNICATIONCOMPONENT_H_

#include <vector>

class CommunicationComponent
{
public:
	virtual void Send(std::vector<unsigned char> _sendbuffer) {};
	virtual void Receive() {};
	std::vector<unsigned char> _receivebuffer;

protected:

};

#endif
