#ifndef GREENLED_H_
#define GREENLED_H_

#include "define.h"
#include "LED.h"

class GreenLED : public LED
{
public:
	virtual void Startup();
	virtual void On();
	virtual void Off();
	virtual void Toggle();
};

#endif /* GREENLED_H_ */
