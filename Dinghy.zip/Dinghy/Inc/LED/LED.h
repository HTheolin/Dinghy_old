#ifndef __LED_H
#define __LED_H

#include "stm32f4xx_hal.h"

class LED
{
public:
	virtual void Startup();
	virtual void On();
	virtual void Off();
	virtual void Toggle();

	GPIO_TypeDef* _gpioport;
	uint16_t _gpiopin;
};

#endif
