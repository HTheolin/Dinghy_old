#ifndef REDLED_H_
#define REDLED_H_

#include "define.h"
#include "LED.h"


class RedLED : public LED
{
public:
	virtual void Startup();
	virtual void On();
	virtual void Off();
	virtual void Toggle();
};

#endif /* GREENLED_H_ */
