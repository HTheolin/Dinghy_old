#ifndef YELLOWLED_H_
#define YELLOWLED_H_

#include "define.h"
#include "LED.h"


class YellowLED : public LED
{
public:
	virtual void Startup();
	virtual void On();
	virtual void Off();
	virtual void Toggle();
};

#endif /* GREENLED_H_ */
