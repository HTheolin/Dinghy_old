#ifndef OPTO_OPTO_H_
#define OPTO_OPTO_H_

#include "stm32f4xx_hal.h"
#include "Component.h"

class opto : public Component
{
public:
	virtual void 	Startup();
	virtual void 	Shutdown();
	virtual void 	Sleep();
	virtual void	WakeUp();
	virtual std::vector<unsigned char> 	Poll();

	int heightCB = 100;
	int state = 0;

};



#endif
