#ifndef __SPI_H
#define __SPI_H

#include "stm32f4xx_hal.h"

#include "Component.h"
#include "CommunicationComponent.h"

class SPI : public Component, CommunicationComponent
{
public:
	virtual void Startup();
	virtual void Shutdown();
	virtual void Sleep();
	virtual void WakeUp();
	virtual std::vector<unsigned char> Poll();

	virtual void Send(std::vector<unsigned char> _sendbuffer);
	virtual void Receive();

	unsigned char GetRegister(int reg);
	void WriteRegister(int reg, int value);

	unsigned char Rx_data;
	SPI_HandleTypeDef _spi;
};

#endif
