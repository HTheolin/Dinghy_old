#ifndef __usart_H
#define __usart_H

#include "stm32f4xx_hal.h"
#include "define.h"
#include "Component.h"
#include "CommunicationComponent.h"

class USARTBase : public Component, public CommunicationComponent
{
public:
	virtual void Startup();
	virtual void Shutdown();
	virtual void Sleep();
	virtual void WakeUp();
	virtual std::vector<unsigned char> Poll();

	virtual void Send(std::vector<unsigned char> _sendbuffer);
	virtual void Receive();

	unsigned char Rx_data;
	UART_HandleTypeDef _uart;
};

#endif
