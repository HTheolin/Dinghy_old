#ifndef __adc1_H
#define __adc1_H

#include "stm32f4xx_hal.h"
#include "define.h"

#include "Component.h"

 class adc : public Component
 {
 public:
	 virtual void Startup();
	 virtual void Shutdown();
	 virtual void Sleep();
	 virtual void WakeUp();
	 virtual std::vector<unsigned char> Poll();

	 ADC_HandleTypeDef _adc;

#if defined(DINGHY_RUD) || defined(DINGHY_CB)
	 enum { buffer_size = 3};
#endif
#ifdef DINGHY_MAIN
	 enum {buffer_size = 5};
#endif
	 int buffer [buffer_size];

		GPIO_TypeDef* _batport;
		uint16_t _batpin;
 };

#endif

