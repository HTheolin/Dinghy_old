#define DINGHY_MAIN
//#define DINGHY_CB
//#define DINGHY_RUD

