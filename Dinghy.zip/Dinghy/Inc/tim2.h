#ifndef __tim2_H
#define __tim2_H

#include "stm32f4xx_hal.h"
#include "Component.h"

 class tim2 : public Component
 {
 public:
	 virtual void Startup();
	 virtual void Shutdown();
	 virtual void Sleep();
	 virtual void WakeUp();
	 virtual std::vector<unsigned char> Poll();

	 TIM_HandleTypeDef tim2;

 	 unsigned int capturedValue;


 };

 extern tim2 _tim2;


#endif
