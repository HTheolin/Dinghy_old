#ifndef __tim3_H
#define __tim3_H

#include "stm32f4xx_hal.h"
#include <string>
#include <sstream>

#include "Component.h"

 class tim3 : public Component
 {
 public:
	 virtual void Startup();
	 virtual void Shutdown();
	 virtual void Sleep();
	 virtual void WakeUp();
	 virtual std::vector<unsigned char> Poll();

	 TIM_HandleTypeDef tim3;
 };

#endif

