#ifndef TIM4_H_
#define TIM4_H_

#include "stm32f4xx_hal.h"
#include "Component.h"

class tim4 : public Component
{
public:
	virtual void Startup();
	virtual void Shutdown();
	virtual void Sleep();
	virtual void WakeUp();
	virtual std::vector<unsigned char> Poll();
	void SetPeriod(unsigned int period);

	TIM_HandleTypeDef _tim4;
	bool _timeout = false;
	int _period = 65000;
};

#endif
