#ifndef USART6_H_
#define USART6_H_

#include "stm32f4xx_hal.h"
#include "USARTBase.h"

//GPS
#include<string>


class usart6 : public USARTBase
{
public:
	virtual void Startup();
	virtual void Shutdown();
	virtual void Sleep();
	virtual void WakeUp();
	virtual std::vector<unsigned char> Poll();

	virtual void Receive();

private:
	std::vector<unsigned char> stringtovec(std::string str);

	std::vector<unsigned char> result;
	std::vector<unsigned char> _ggamsg;
	unsigned int pos = 0;
	bool recording = false;
};

#endif
