#include "Bluetooth\Bluetooth.h"

void Bluetooth::Startup()
{
	while(1){};
}

bool Bluetooth::ConnectCB()
{
	std::vector<unsigned char> cmd;
	std::vector<unsigned char> reply;

	cmd.push_back('C');
	cmd.push_back(',');
	cmd.push_back('0');
	cmd.push_back('0');
	cmd.push_back('0');
	cmd.push_back('6');
	cmd.push_back('6');
	cmd.push_back('6');
	cmd.push_back('8');
	cmd.push_back('3');
	cmd.push_back('7');
	cmd.push_back('F');
	cmd.push_back('8');
	cmd.push_back('0');
	cmd.push_back('\r');
	cmd.push_back('\n');

	Send(cmd);

	reply.push_back('T');
	reply.push_back('R');
	reply.push_back('Y');
	reply.push_back('I');
	reply.push_back('N');
	reply.push_back('G');
	reply.push_back('\r');
	reply.push_back('\n');

	bool result = WaitForReply(reply.size(), reply.data(), 1000);
	if(result == false)
	{
		return false;
	}
	reply.clear();

	reply.push_back('C');
	reply.push_back('O');
	reply.push_back('N');
	reply.push_back('N');
	reply.push_back('E');
	reply.push_back('C');
	reply.push_back('T');
	reply.push_back(',');
	reply.push_back('0');
	reply.push_back('0');
	reply.push_back('0');
	reply.push_back('6');
	reply.push_back('6');
	reply.push_back('6');
	reply.push_back('8');
	reply.push_back('3');
	reply.push_back('7');
	reply.push_back('F');
	reply.push_back('8');
	reply.push_back('0');
	reply.push_back(',');
	reply.push_back('0');
	reply.push_back('\r');
	reply.push_back('\n');

	result = WaitForReply(reply.size(), reply.data(), 10000);
	if(result == false)
	{
		return false;
	}

	return true;
}

bool Bluetooth::ConnectRUD()
{
	std::vector<unsigned char> cmd;
	std::vector<unsigned char> reply;

	cmd.push_back('C');
	cmd.push_back(',');
	cmd.push_back('0');
	cmd.push_back('0');
	cmd.push_back('0');
	cmd.push_back('6');
	cmd.push_back('6');
	cmd.push_back('6');
	cmd.push_back('8');
	cmd.push_back('3');
	cmd.push_back('7');
	cmd.push_back('F');
	cmd.push_back('9');
	cmd.push_back('9');
	cmd.push_back('\r');
	cmd.push_back('\n');

	Send(cmd);

	reply.push_back('T');
	reply.push_back('R');
	reply.push_back('Y');
	reply.push_back('I');
	reply.push_back('N');
	reply.push_back('G');
	reply.push_back('\r');
	reply.push_back('\n');

	bool result = WaitForReply(reply.size(), reply.data(), 1000);
	if(result == false)
	{
		return false;
	}
	reply.clear();

	reply.push_back('C');
	reply.push_back('O');
	reply.push_back('N');
	reply.push_back('N');
	reply.push_back('E');
	reply.push_back('C');
	reply.push_back('T');
	reply.push_back(',');
	reply.push_back('0');
	reply.push_back('0');
	reply.push_back('0');
	reply.push_back('6');
	reply.push_back('6');
	reply.push_back('6');
	reply.push_back('8');
	reply.push_back('3');
	reply.push_back('7');
	reply.push_back('F');
	reply.push_back('9');
	reply.push_back('9');
	reply.push_back(',');
	reply.push_back('0');
	reply.push_back('\r');
	reply.push_back('\n');

	result = WaitForReply(reply.size(), reply.data(), 10000);
	if(result == false)
	{
		return false;
	}

	return true;
}

bool Bluetooth::Disconnect()
{
	std::vector<unsigned char> cmd;
	std::vector<unsigned char> reply;

	cmd.push_back('K');
	cmd.push_back(',');
	cmd.push_back('1');
	cmd.push_back('\r');
	cmd.push_back('\n');

	Send(cmd);

	reply.push_back('K');
	reply.push_back('I');
	reply.push_back('L');
	reply.push_back('L');
	reply.push_back('\r');
	reply.push_back('\n');

	bool result = WaitForReply(reply.size(), reply.data(), 3000);
	if(result == false)
	{
		return false;
	}

	reply.clear();

	reply.push_back('D');
	reply.push_back('I');
	reply.push_back('S');
	reply.push_back('C');
	reply.push_back('O');
	reply.push_back('N');
	reply.push_back('N');
	reply.push_back('E');
	reply.push_back('C');
	reply.push_back('T');

	result = WaitForReply(reply.size(), reply.data(), 3000);
	if(result == false)
	{
		return false;
	}

	return true;
}
bool Bluetooth::EnterCommandMode()
{
	std::vector<unsigned char> cmd;
	std::vector<unsigned char> reply;
	cmd.push_back('$');
	cmd.push_back('$');
	cmd.push_back('$');

	Send(cmd);

	reply.push_back('C');
	reply.push_back('M');
	reply.push_back('D');
	reply.push_back('\r');
	reply.push_back('\n');

	bool result = WaitForReply(reply.size(), reply.data(), 1000);
	if(result == false)
	{
		return false;
	}
	return true;
}
bool Bluetooth::ExitCommandMode()
{
	std::vector<unsigned char> cmd;
	cmd.push_back('-');
	cmd.push_back('-');
	cmd.push_back('-');
	cmd.push_back('-');
	cmd.push_back('\r');
	cmd.push_back('\n');
	Send(cmd);
	HAL_Delay(50);
}

void Bluetooth::Reset()
{

}

void Bluetooth::SetMaster()
{
	std::vector<unsigned char> cmd;
	cmd.push_back('S');
	cmd.push_back('M');
	cmd.push_back(',');
	cmd.push_back('1');
	cmd.push_back('\r');
	cmd.push_back('\n');
	Send(cmd);
	HAL_Delay(100);
}

void Bluetooth::SetAuth()
{
	std::vector<unsigned char> cmd;
	cmd.push_back('S');
	cmd.push_back('A');
	cmd.push_back(',');
	cmd.push_back('0');
	cmd.push_back('\r');
	cmd.push_back('\n');
	Send(cmd);
	HAL_Delay(100);
}

void Bluetooth::Restart()
{
	std::vector<unsigned char> cmd;
	cmd.push_back('R');
	cmd.push_back(',');
	cmd.push_back('1');
	cmd.push_back('\r');
	cmd.push_back('\n');
	Send(cmd);
	HAL_Delay(1000);
}

bool Bluetooth::WaitForReply(int length, unsigned char* reply, unsigned int timeout)
{
	extern tim4 _tim4;
	//_tim4.SetPeriod(timeout);
	_tim4.Startup();

	unsigned char startpos;
	unsigned char pos;

	unsigned int timer = (__HAL_TIM_GET_COUNTER(&_tim4._tim4));
	__HAL_TIM_SET_COUNTER(&_tim4._tim4, 0);

	while(timer/84000 < timeout)
	{
		timer = __HAL_TIM_GET_COUNTER(&_tim4._tim4);
		int size = _receivebuffer.size()-length;
		startpos = 0;
		while(startpos <= size)
		{
			pos = 0;
			while(_receivebuffer.at(startpos+pos) == reply[pos])
			{
				pos++;
				if(pos == length)
				{
					_receivebuffer.erase(_receivebuffer.begin(), _receivebuffer.begin()+startpos+pos);
					return true;
				}
			}
			startpos++;
		}
	}
	return false;
}

bool Bluetooth::Connected()
{
	while(1){};
	return false;
}
