#include "Bluetooth\Bluetooth1.h"
#include "define.h"

void Bluetooth1::Startup()
{
	__HAL_RCC_USART1_CLK_ENABLE();

	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	//Bluetooth connection status PA8
	GPIO_InitStruct.Pin = GPIO_PIN_8;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

#if defined(DINGHY_MAIN) || defined(DINGHY_RUD)
	//Bluetooth reset
	GPIO_InitStruct.Pin = GPIO_PIN_9;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	//GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct); // Not needed for cb

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
#endif
	_uart.Instance = USART1;
	_uart.Init.BaudRate = 9600;
	_uart.Init.WordLength = UART_WORDLENGTH_8B;
	_uart.Init.StopBits = UART_STOPBITS_1;
	_uart.Init.Parity = UART_PARITY_NONE;
	_uart.Init.Mode = UART_MODE_TX_RX;
	_uart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	_uart.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&_uart);

	HAL_NVIC_SetPriority(USART1_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(USART1_IRQn);

	HAL_UART_Receive_IT(&_uart, &Rx_data, 1);	//activate UART receive interrupt every time
}

void Bluetooth1::Reset()
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
}

bool Bluetooth1::Connected()
{
	return(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8));
}

extern Bluetooth1 _bt1;
extern "C" void USART1_IRQHandler(void)
{
	HAL_UART_IRQHandler(&_bt1._uart);
}
