#include "Bluetooth\Bluetooth2.h"
#include "define.h"

void Bluetooth2::Startup()
{
	__HAL_RCC_USART2_CLK_ENABLE();

	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : GPIOC_3 Bluetooth 2 connection status */
	GPIO_InitStruct.Pin = GPIO_PIN_3;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	//Bluetooth reset
	GPIO_InitStruct.Pin = GPIO_PIN_2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	//GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);

	//HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);

	_uart.Instance = USART2;
	_uart.Init.BaudRate = 9600;
	_uart.Init.WordLength = UART_WORDLENGTH_8B;
	_uart.Init.StopBits = UART_STOPBITS_1;
	_uart.Init.Parity = UART_PARITY_NONE;
	_uart.Init.Mode = UART_MODE_TX_RX;
	_uart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	_uart.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&_uart);

	HAL_NVIC_SetPriority(USART2_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(USART2_IRQn);

	HAL_UART_Receive_IT(&_uart, &Rx_data, 1);	//activate UART receive interrupt every time
}

void Bluetooth2::Reset()
{
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET);
}

bool Bluetooth2::Connected()
{
	return(HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_3));
}

#ifdef DINGHY_MAIN
extern Bluetooth2 _bt2;
extern "C" void USART2_IRQHandler(void)
{
	HAL_UART_IRQHandler(&_bt2._uart);
}
#endif
