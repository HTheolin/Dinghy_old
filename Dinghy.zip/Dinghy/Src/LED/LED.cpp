#include "LED\LED.h"

void LED::Startup()
{
}

void LED::On()
{
}

void LED::Off()
{
}

void LED::Toggle()
{
}
