#include "LED\YellowLED.h"

void YellowLED::Startup()
{
#ifdef DINGHY_MAIN
	_gpioport = GPIOC;
	_gpiopin = GPIO_PIN_11;
#endif
#ifdef DINGHY_CB
	_gpioport = GPIOB;
	_gpiopin = GPIO_PIN_1;
#endif
#ifdef DINGHY_RUD
	_gpioport = GPIOB;
	_gpiopin = GPIO_PIN_1;
#endif
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = _gpiopin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(_gpioport, &GPIO_InitStruct);

}

void YellowLED::On()
{
	HAL_GPIO_WritePin(_gpioport, _gpiopin, GPIO_PIN_SET);
}

void YellowLED::Off()
{
	HAL_GPIO_WritePin(_gpioport, _gpiopin, GPIO_PIN_RESET);
}

void YellowLED::Toggle()
{
	HAL_GPIO_TogglePin(_gpioport, _gpiopin);
}
