#include "OPTO\opto.h"

void opto::Startup()
{
	GPIO_InitTypeDef GPIO_InitStruct;

	//Input pins, configured for external interrupt
	GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pin : Opto Switch ON/OFF */
	/* 1: OFF, 0: ON*/
	GPIO_InitStruct.Pin = GPIO_PIN_15;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_PULLDOWN;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* EXTI interrupt init*/
	HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 1);
	HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
}
void opto::Shutdown()
{

}
void opto::Sleep()
{

}
void opto::WakeUp()
{

}
std::vector<unsigned char> 	opto::Poll()
{

}
#ifdef DINGHY_MAIN
#include "LED\GreenLED.h"
#include "LED\YellowLED.h"

#include "Bluetooth\Bluetooth2.h"

extern GreenLED _greenled;
extern YellowLED _yellowled;
extern opto _opto;

#define GREEN_PIN HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_6)
#define YELLOW_PIN HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_7)

extern "C" void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{

	if(GPIO_Pin == GPIO_PIN_6)
	{
		_greenled.Toggle();
	}

	if(GPIO_Pin == GPIO_PIN_7)
	{
		_yellowled.Toggle();
	}
	if(_opto.state==0)
	{
		if(YELLOW_PIN && !GREEN_PIN)
		{
			_opto.heightCB--;
			_opto.state = 3;
		}
		else if(!YELLOW_PIN && GREEN_PIN)
		{
			_opto.heightCB++;
			_opto.state = 1;
		}
	}
	else if(_opto.state==1)
	{
		if(YELLOW_PIN && GREEN_PIN)
		{
			_opto.heightCB++;
			_opto.state = 2;
		}
		else if(!YELLOW_PIN && !GREEN_PIN)
		{
			_opto.heightCB--;
			_opto.state = 0;
		}
	}
	else if(_opto.state==2)
	{
		if(YELLOW_PIN && !GREEN_PIN)
		{
			_opto.heightCB++;
			_opto.state = 3;
		}
		else if (!YELLOW_PIN && GREEN_PIN)
		{
			_opto.heightCB--;
			_opto.state = 1;
		}
	}
	else if(_opto.state==3)
	{
		if(!YELLOW_PIN && !GREEN_PIN)
		{
			_opto.heightCB++;
			_opto.state = 0;
		}
		else if(YELLOW_PIN && GREEN_PIN)
		{
			_opto.heightCB--;
			_opto.state = 2;
		}
	}
}
#endif

extern "C" void EXTI9_5_IRQHandler(void)
{
	HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_6);
	HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_7);
}
