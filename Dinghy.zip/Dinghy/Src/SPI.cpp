#include <SPI.h>

void SPI::Startup()
{
	_spi.Instance = SPI1;
	_spi.Init.Mode = SPI_MODE_MASTER;
	_spi.Init.Direction = SPI_DIRECTION_2LINES;
	_spi.Init.DataSize = SPI_DATASIZE_8BIT;
	_spi.Init.CLKPolarity = SPI_POLARITY_LOW;
	_spi.Init.CLKPhase = SPI_PHASE_1EDGE;
	_spi.Init.NSS = SPI_NSS_SOFT;
	_spi.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
	_spi.Init.FirstBit = SPI_FIRSTBIT_MSB;
	_spi.Init.TIMode = SPI_TIMODE_DISABLE;
	_spi.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	_spi.Init.CRCPolynomial = 10;

	  if (HAL_SPI_Init(&_spi) != HAL_OK)
	  {
		  while(1){}
	  }
}

void HAL_SPI_MspInit(SPI_HandleTypeDef* spiHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(spiHandle->Instance==SPI1)
  {
  /* USER CODE BEGIN SPI1_MspInit 0 */

  /* USER CODE END SPI1_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_SPI1_CLK_ENABLE();

    /**SPI1 GPIO Configuration
    PA5     ------> SPI1_SCK
    PA6     ------> SPI1_MISO
    PA7     ------> SPI1_MOSI
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Peripheral interrupt init */
    HAL_NVIC_SetPriority(SPI1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(SPI1_IRQn);
  /* USER CODE BEGIN SPI1_MspInit 1 */
    GPIO_InitStruct.Pin = GPIO_PIN_4;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = 0;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  /* USER CODE END SPI1_MspInit 1 */
  }
}

void SPI::Shutdown()
{
}

void SPI::Sleep()
{
}

void SPI::WakeUp()
{
}

std::vector<unsigned char> SPI::Poll()
{

	std::vector<unsigned char> temp;

	//MAG
	temp.push_back(0);
	temp.push_back(0);

	temp.push_back(0);
	temp.push_back(0);

	temp.push_back(0);
	temp.push_back(0);

	//ACC
	temp.push_back(GetRegister(59));
	temp.push_back(GetRegister(60));

	temp.push_back(GetRegister(61));
	temp.push_back(GetRegister(62));

	temp.push_back(GetRegister(63));
	temp.push_back(GetRegister(64));

	//GYRO
	temp.push_back(GetRegister(67));
	temp.push_back(GetRegister(68));

	temp.push_back(GetRegister(69));
	temp.push_back(GetRegister(70));

	temp.push_back(GetRegister(71));
	temp.push_back(GetRegister(72));

	return temp;
}

void SPI::Receive()
{

}

void SPI::Send(std::vector<unsigned char> _sendbuffer)
{
}

unsigned char SPI::GetRegister(int reg)
{
	unsigned char senddata[2];
	unsigned char receivedata[2];
	senddata[0] = 0b10000000 | reg;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	HAL_SPI_TransmitReceive(&_spi, senddata, receivedata, 2, 3000);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	return receivedata[1];
}

void SPI::WriteRegister(int reg, int value)
{
	unsigned char senddata[2];
	unsigned char receivedata[2];
	senddata[0] = reg;
	senddata[1] = value;
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	HAL_SPI_Transmit(&_spi, senddata, 2, 3000);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
}
