#include <USARTBase.h>

void USARTBase::Startup()
{
}

void USARTBase::Shutdown()
{
}

void USARTBase::Sleep()
{
}

void USARTBase::WakeUp()
{
}

//Retrieves the first valid command received from the receive queue
std::vector<unsigned char> USARTBase::Poll()
{
	_receivebuffer.clear();
	/*
	//Loop through the queue
	for(unsigned int i = 0; i < _receivebuffer.size()-1; i++)
	{
		//Look for end of message identifiers
		if (_receivebuffer.at(i) == '\r' && _receivebuffer.at(i+1) == '\n')
		{
			//Build return vector from receive buffer
			std::vector<unsigned char> temp(_receivebuffer.begin(), _receivebuffer.begin() + i);
			_receivebuffer.erase(_receivebuffer.begin(), _receivebuffer.begin() + i+2);
			return temp;
		}
	}*/
	std::vector<unsigned char> temp;
	temp.push_back('0');
	return temp;
}

void USARTBase::Receive()
{
	_receivebuffer.push_back(Rx_data);
	HAL_UART_Receive_IT(&_uart, &Rx_data, 1);	//activate UART receive interrupt every time

	//HAL_UART_Transmit(&_uart, &Rx_data, 1, 3000);
}

void USARTBase::Send(std::vector<unsigned char> _sendbuffer)
{
	HAL_UART_Transmit(&_uart, _sendbuffer.data(), _sendbuffer.size(), 1000);
}

#include "Bluetooth\Bluetooth1.h"
#include "Bluetooth\Bluetooth2.h"
#include "usart6.h"

extern Bluetooth1 _bt1;
extern Bluetooth2 _bt2;
extern usart6 _usart6;

extern "C" void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)	//current UART
	{
		_bt1.Receive();
	}
#ifdef DINGHY_MAIN
	if (huart->Instance == USART2)	//current UART
	{
		_bt2.Receive();
	}
	if (huart->Instance == USART6)	//current UART
	{
		_usart6.Receive();
	}
#endif
}
