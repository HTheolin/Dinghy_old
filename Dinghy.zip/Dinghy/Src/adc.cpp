#include <adc.h>
//#include "gpio.h"

DMA_HandleTypeDef hdma_adc1;

/* Differential Pressure Sensor */

/* ADC1 init function */
void adc::Startup(void)
{
	int adc_channels = 3;
#ifdef DINGHY_MAIN
	adc_channels = 5;
#endif

			/* DMA controller clock enable */
			__HAL_RCC_DMA2_CLK_ENABLE();

	/* DMA interrupt init */
	/* DMA2_Stream0_IRQn interrupt configuration */
	//HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
	//HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);


	ADC_ChannelConfTypeDef sConfig;

	/**Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
	 */
	_adc.Instance = ADC1;
	_adc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
	_adc.Init.Resolution = ADC_RESOLUTION_12B;
	_adc.Init.ScanConvMode = ENABLE;
	_adc.Init.ContinuousConvMode = ENABLE;
	_adc.Init.DiscontinuousConvMode = DISABLE;
	_adc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
	_adc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	_adc.Init.NbrOfConversion = adc_channels;
	_adc.Init.DMAContinuousRequests = ENABLE;
	_adc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	if (HAL_ADC_Init(&_adc) != HAL_OK)
	{
		//Error_Handler();
	}

	/*------- Configuration and inits for each adc-channel -------*/

	/*------- Battery Voltage -------*/
	sConfig.Channel = ADC_CHANNEL_10;
	sConfig.Rank = 1;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

#ifdef DINGHY_MAIN

	/*------- Opto 2 Diode Failure -------*/ // blir h�g (3v3?) eller 0 (vid short circuit)
	sConfig.Channel = ADC_CHANNEL_8;
	sConfig.Rank = 2;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

	/*------- Opto 2 Transistor Failure -------*/
	sConfig.Channel = ADC_CHANNEL_7;
	sConfig.Rank = 3;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

	/*------- Opto 1 Diode Failure -------*/
	sConfig.Channel = ADC_CHANNEL_14;
	sConfig.Rank = 4;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

	/*------- Opto 1 Transistor Failure -------*/
	sConfig.Channel = ADC_CHANNEL_15;
	sConfig.Rank = 5;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

#endif
#ifdef DINGHY_RUD

	/*------- Strain gauge 1 -------*/
	sConfig.Channel = ADC_CHANNEL_6;
	sConfig.Rank = 2;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

	/*------- Strain gauge - Open/short detection -------*/
	sConfig.Channel = ADC_CHANNEL_7;
	sConfig.Rank = 3;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

#endif
#ifdef DINGHY_CB
	/*------- Pressure Sensor -------*/
	sConfig.Channel = ADC_CHANNEL_0;
	sConfig.Rank = 2;
	sConfig.SamplingTime = ADC_SAMPLETIME_56CYCLES;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}

	/*------- Supply Voltage Measurement for Pressure Sensor -------*/
	sConfig.Channel = ADC_CHANNEL_4;
	sConfig.Rank = 3;
	if (HAL_ADC_ConfigChannel(&_adc, &sConfig) != HAL_OK)
	{
		//Error_Handler();
	}
#endif
}

extern adc _adc;
void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{
	GPIO_InitTypeDef GPIO_InitStruct;

	/* Peripheral clock enable */
	__HAL_RCC_ADC1_CLK_ENABLE();

	/* Battery Measurement Voltage */
	GPIO_InitStruct.Pin = GPIO_PIN_0;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/* Battery Measurement ON/OFF */
	_adc._batport = GPIOC;
	_adc._batpin = GPIO_PIN_1;

#ifdef DINGHY_MAIN

	/* Opto Switch Diode (PB0) Transistor (PB1) Failure */
	GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/* Opto Switch Diode (PC4) Transistor (PC5) Failure */
	GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/* Battery Measurement ON/OFF */
	_adc._batport = GPIOC;
	_adc._batpin = GPIO_PIN_8;
#endif
#ifdef DINGHY_RUD
	/* Strain Gauge (PA6) Open/Short Detection (PA7) */
	GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/* Strain Gauge ON/OFF */
	/* 1: OFF, 0: ON */
	GPIO_InitStruct.Pin = GPIO_PIN_2;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
#endif
#ifdef DINGHY_CB
	/* Pressure Sensor (PA0) Supply Voltage Measurement (PA4) */
	GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_4;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/* Battery Measurement ON/OFF */
	/* 1: ON, 0: OFF */
	GPIO_InitStruct.Pin = GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/* Pressure Sensor ON/OFF */
	/* 1: ON, 0: OFF */
	GPIO_InitStruct.Pin = GPIO_PIN_1;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
#endif

	/* Battery Measurement ON/OFF */
	/* 1: ON, 0: Off */
	GPIO_InitStruct.Pin = _adc._batpin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(_adc._batport, &GPIO_InitStruct);

	/* Peripheral DMA init*/

	hdma_adc1.Instance = DMA2_Stream0;
	hdma_adc1.Init.Channel = DMA_CHANNEL_0;
	hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
	hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
	hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
	hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
	hdma_adc1.Init.MemDataAlignment = DMA_PDATAALIGN_WORD;
	hdma_adc1.Init.Mode = DMA_CIRCULAR;
	hdma_adc1.Init.Priority = DMA_PRIORITY_HIGH;
	hdma_adc1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
	if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
	{
		//Error_Handler();
	}

	__HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc1);

	HAL_ADC_Start_DMA(&_adc._adc, (uint32_t*) _adc.buffer, _adc.buffer_size);

}

void adc::Shutdown()
{

}
void adc::Sleep()
{

}
void adc::WakeUp()
{

}

std::vector<unsigned char> adc::Poll()
{
	HAL_GPIO_WritePin(_batport, _batpin, GPIO_PIN_SET);
	HAL_Delay(300);
	HAL_ADC_Stop_DMA(&_adc);

	std::vector<unsigned char> temp;
	unsigned char c1,c2;

#if defined(DINGHY_RUD) || defined(DINGHY_CB)
	c1 = buffer[1];
	c2 = buffer[1] >> 8;
	temp.push_back(c2);
	temp.push_back(c1);
#endif

	c1 = buffer[0];
	c2 = buffer[0] >> 8;
	temp.push_back(c2);
	temp.push_back(c1);

	HAL_ADC_Start_DMA(&_adc, (uint32_t*) buffer, buffer_size);
	HAL_GPIO_WritePin(_batport, _batpin, GPIO_PIN_RESET);

	return temp;
}
