#include "stm32f4xx_hal.h"
#include "define.h"
#include "adc.h"
#include "gpio.h"
#include "tim4.h"
#include "LED\GreenLED.h"
#include "LED\RedLED.h"
#include "LED\YellowLED.h"
#include "Bluetooth\Bluetooth1.h"

std::vector<unsigned char> cbData;
std::vector<unsigned char> rudData;

//ADC
adc _adc;

//LEDs
GreenLED _greenled;
RedLED _redled;
YellowLED _yellowled;

//Bluetooth
Bluetooth1 _bt1;

//Tim4 for timout testing
tim4 _tim4;

#ifdef DINGHY_MAIN
#include "usart6.h"
#include "SPI.h"
#include "OPTO\opto.h"
#include "Bluetooth\Bluetooth2.h"
opto _opto;
SPI _spi;
usart6 _usart6;
Bluetooth2 _bt2;
#endif

#ifdef DINGHY_CB
#include "tim2.h"
#include "tim3.h"
tim2 _tim2;
tim3 _tim3;
#endif

void SystemClock_Config(void);
void Error_Handler(int errorcode);
bool getBatteryStatus();

#if  defined(DINGHY_RUD) || defined(DINGHY_CB)
void nodeSerializeSend()
{
	std::vector<unsigned char> data;
	std::vector<unsigned char> temp;

	/* Message ID */
#ifdef DINGHY_RUD
	data.push_back(0);
#endif
#ifdef DINGHY_CB
	data.push_back(1);
#endif
	/* Error Byte */
	data.push_back(0);

	/* ADC Sensors and Battery Voltage */
	temp = _adc.Poll();
	data.insert(data.end(),temp.begin(),temp.end());

	_bt1.Send(data);
}
#endif

#ifdef DINGHY_MAIN
void packet_and_send(void)
{
	std::vector<unsigned char> data;
	std::vector<unsigned char> temp;

	/* Message ID */
	data.push_back(2);

	/* Error Byte */
	if(!getBatteryStatus())
	{
		data.push_back(1);
	}
	else
	{
		data.push_back(0);
	}

	/* Pressure from CB */
	data.push_back(cbData.at(2));
	data.push_back(cbData.at(3));

	/* Strain from RUD */
	data.push_back(rudData.at(2));
	data.push_back(rudData.at(3));

	/* Bat from main */
	temp = _adc.Poll();
	data.push_back(temp.at(0));
	data.push_back(temp.at(1));

	/* Bat from CB */
	data.push_back(cbData.at(4));
	data.push_back(cbData.at(5));

	/* Bat from RUD */
	data.push_back(rudData.at(4));
	data.push_back(rudData.at(4));

	/* Height */
	data.push_back(_opto.heightCB);

	/* IMU */
	temp = _spi.Poll();
	for(int i = 0; i < temp.size(); i++)
	{
		data.push_back(temp.at(i));
	}

	/* GPS */
	temp = _usart6.Poll();
	data.insert(data.end(), temp.begin(), temp.end());

	_bt2.Send(data);
}
#endif

bool getBatteryStatus()
{
	_redled.Off();
	if (_adc.buffer[0] > 2850)		// If battery is nearly depleted
	{
		_redled.On();
		return false;
	}
	return true;
}

#ifdef DINGHY_RUD
bool getStrainGaugeStatus()
{
	_redled.Off();
	if (_adc.buffer[2] > 0)
	{
		_redled.On();
		return false;
	}
	return true;
}
#endif

#ifdef DINGHY_CB
bool getPressureStatus()
{
	_redled.Off();
	if (_adc.buffer[2] > 2850)
	{
		_redled.On();
		return false;
	}
	return true;
}
#endif

#ifdef DINGHY_MAIN
bool getDiodeStatus()
{
	_redled.Off();
	/*if (_adc.buffer[0] > 2850)
	{
		_redled.On();
		return false;
	}*/
	return true;
}
#endif

int main(void)
{
	HAL_Init();
	SystemClock_Config();

	MX_GPIO_Init();

#ifdef DINGHY_CB
	//_tim2.Startup();
	//_tim3.Startup();
	//HAL_TIM_IC_Start_IT(&_tim2.tim2, TIM_CHANNEL_1);

	//HAL_TIM_PWM_Start(&_tim3.tim3, TIM_CHANNEL_1);
#endif

#ifdef DINGHY_MAIN
	_spi.Startup();
	_spi.WriteRegister(106, 0b00010000); //Turn off I2C for IMU, move to SPI.cpp later
	_opto.Startup();
	_bt2.Startup();

	//GPS STUFF!
	_usart6.Startup();

#endif

	//LED startup
	_greenled.Startup();
	_redled.Startup();
	_yellowled.Startup();

	_greenled.Off();
	_redled.Off();
	_yellowled.Off();

	//Bluetooth startup
	_bt1.Startup();
	_bt1.Reset();

	//adc startup
	_adc.Startup();

	HAL_Delay(1000);

#ifdef DINGHY_MAIN
	/*_bt1.EnterCommandMode();
	_bt1.SetMaster();
	_bt1.SetAuth();
	_bt1.Restart();*/
#endif

	while (1)
	{

#ifdef DINGHY_MAIN

		while(!_bt1.EnterCommandMode())
		{
			Error_Handler(0);
		}
		while(!_bt1.ConnectCB())
		{
			//Error_Handler(1);
		}
		_greenled.Toggle();

		while(_bt1._receivebuffer.size() < 6){}

		cbData = _bt1._receivebuffer;
		_bt1._receivebuffer.clear();

		while(!_bt1.EnterCommandMode())
		{
			Error_Handler(2);
		}
		while(!_bt1.Disconnect())
		{
			Error_Handler(3);
		}
		while(!_bt1.EnterCommandMode())
		{
			Error_Handler(4);
		}
		while(!_bt1.ConnectRUD())
		{

		}
		_greenled.Toggle();
		while(_bt1._receivebuffer.size() < 6) {}

		rudData = _bt1._receivebuffer;
		_bt1._receivebuffer.clear();

		while(!_bt1.EnterCommandMode())
		{
			Error_Handler(6);
		}
		while(!_bt1.Disconnect())
		{
			Error_Handler(7);
		}

		_bt1._receivebuffer.clear();
		if(_bt2.Connected())
		{
			packet_and_send();
		}
#endif

#if defined(DINGHY_RUD) || defined(DINGHY_CB)
		if(_bt1.Connected())
		{
			nodeSerializeSend();
			while(_bt1.Connected()){}
		}
#endif
	}
}

void SystemClock_Config(void)
{

	RCC_OscInitTypeDef RCC_OscInitStruct;
	RCC_ClkInitTypeDef RCC_ClkInitStruct;

	__HAL_RCC_PWR_CLK_ENABLE();
	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = 16;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
	RCC_OscInitStruct.PLL.PLLM = 16;
	RCC_OscInitStruct.PLL.PLLN = 336;
	RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
	RCC_OscInitStruct.PLL.PLLQ = 7;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler(99);
	}

	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	{
		Error_Handler(99);
	}

	HAL_RCC_MCOConfig(RCC_MCO2, RCC_MCO2SOURCE_SYSCLK, RCC_MCODIV_1);
	HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);
	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
	HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);

	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}

void Error_Handler(int errorcode)
{
	while(1)
	{
		errorcode++;
		_redled.Toggle();
		HAL_Delay(500);
	}
}

