#include "tim2.h"
#include "gpio.h"

 unsigned int startvalue = 0;
 unsigned int stopvalue = 0;
 unsigned int capturedvalue = 0;
 unsigned int done = 0;

/* TIM2 init function */
void tim2::Startup()
{
  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  tim2.Instance = TIM2;
  tim2.Init.Prescaler = 0;
  tim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  tim2.Init.Period = 4294967295;
  tim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  if (HAL_TIM_Base_Init(&tim2) != HAL_OK)
  {
    //Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&tim2, &sClockSourceConfig) != HAL_OK)
  {
    //Error_Handler();
  }
  if (HAL_TIM_IC_Init(&tim2) != HAL_OK)
  {
    //Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&tim2, &sMasterConfig) != HAL_OK)
  {
    //Error_Handler();
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_BOTHEDGE;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 15;
  if (HAL_TIM_IC_ConfigChannel(&tim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    //Error_Handler();
  }

  HAL_NVIC_SetPriority(TIM2_IRQn, 0, 1);
  HAL_NVIC_EnableIRQ(TIM2_IRQn);

}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* tim_baseHandle)
{

  /*GPIO_InitTypeDef GPIO_InitStruct;
  if(tim_baseHandle->Instance==TIM2)
  {

    __HAL_RCC_TIM2_CLK_ENABLE();


    GPIO_InitStruct.Pin = GPIO_PIN_15;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF1_TIM2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  }
  if(tim_baseHandle->Instance==TIM3)
  {
    //__HAL_RCC_TIM3_CLK_ENABLE();

  }*/
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* tim_baseHandle)
{

  if(tim_baseHandle->Instance==TIM2)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM2_CLK_DISABLE();

    /**TIM2 GPIO Configuration
    PA0-WKUP     ------> TIM2_CH1
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_0);
  }

  if(tim_baseHandle->Instance==TIM3)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM3_CLK_DISABLE();

  }
  if(tim_baseHandle->Instance==TIM4)
  {
    /* Peripheral clock disable */
    __HAL_RCC_TIM4_CLK_DISABLE();

    /* Peripheral interrupt Deinit*/
    HAL_NVIC_DisableIRQ(TIM4_IRQn);
  }
}

void tim2::Shutdown()
{

}
void tim2::Sleep()
{

}
void tim2::WakeUp()
{

}
std::vector<unsigned char> tim2::Poll()
{
	std::vector<unsigned char> temp;
	unsigned char c1 = capturedValue;
	unsigned char c2 = capturedValue >> 8;
	unsigned char c3 = capturedValue >> 16;
	unsigned char c4 = capturedValue >> 24;
	temp.push_back(c1);
	temp.push_back(c2);
	temp.push_back(c3);
	temp.push_back(c4);

	return temp;
}

#ifdef DINGHY_CB
extern "C"
{
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	//if high (rising)
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_15))
	{
		if (done == 0)
		{
			startvalue = htim->Instance->CCR1;
			done = 1;
		}
	}
	else
	{
		if (done == 1)
		{
			stopvalue = htim->Instance->CCR1;
			if (stopvalue < startvalue)						// In case something went wrong, sample again.
			{
				htim->Instance->CCR1 = 0;
				done = 0;
			}
			else
			{
				capturedvalue = stopvalue - startvalue;
				htim->Instance->CCR1 = 0;
				done = 0;
				_tim2.capturedValue = (((capturedvalue/84)/29)/2);		// Divide by 84 for microseconds, divide by 29 and 2 for value in centimeters
			}
		}
	}

}
}

extern "C" void TIM2_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&_tim2.tim2);
}
#endif


