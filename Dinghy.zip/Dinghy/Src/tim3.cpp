#include "tim3.h"
#include "gpio.h"

/* TIM3 init function */
void tim3::Startup()
{
  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  tim3.Instance = TIM3;
  tim3.Init.Prescaler = 84;
  tim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  tim3.Init.Period = 1000000;
  tim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  if (HAL_TIM_Base_Init(&tim3) != HAL_OK)
  {
    //Error_Handler();
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&tim3, &sClockSourceConfig) != HAL_OK)
  {
    //Error_Handler();
  }

  if (HAL_TIM_PWM_Init(&tim3) != HAL_OK)
  {
    //Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&tim3, &sMasterConfig) != HAL_OK)
  {
    //Error_Handler();
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 10;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&tim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    //Error_Handler();
  }

  /* HAL_TIM_MspPostInit(&htim3); */
  GPIO_InitTypeDef GPIO_InitStruct;
    /**TIM3 GPIO Configuration
    PA6     ------> TIM3_CH1
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

void tim3::Shutdown()
{

}
void tim3::Sleep()
{

}
void tim3::WakeUp()
{

}
std::vector<unsigned char> tim3::Poll()
{
	std::vector<unsigned char> result;
	return result;
}

#ifdef DINGHY_CB
extern tim3 _tim3;
extern "C" void TIM3_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&_tim3.tim3);
}
#endif
