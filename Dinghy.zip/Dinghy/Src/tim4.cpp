#include "tim4.h"

void tim4::Startup()
{
	__HAL_RCC_TIM2_CLK_ENABLE();

	_timeout = false;

	TIM_ClockConfigTypeDef sClockSourceConfig;
	TIM_MasterConfigTypeDef sMasterConfig;

	//1 tick every 1msec
	//84,000,000MHz / (4*21000) = 1000tick/s
	_tim4.Instance = TIM2;
	_tim4.Init.Prescaler = 0;
	_tim4.Init.CounterMode = TIM_COUNTERMODE_UP;
	_tim4.Init.Period = 0xFFFFFFFF; //21000000*_period;
	_tim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV4;
	if (HAL_TIM_Base_Init(&_tim4) != HAL_OK)
	{
		while(1){};
	}

	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&_tim4, &sClockSourceConfig) != HAL_OK)
	{
		while(1){};
	}

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&_tim4, &sMasterConfig) != HAL_OK)
	{
		while(1){};
	}



    /* Peripheral interrupt init */
    //HAL_NVIC_SetPriority(TIM4_IRQn, 4, 4);
    //HAL_NVIC_EnableIRQ(TIM4_IRQn);

    HAL_TIM_Base_Start(&_tim4);
}

void tim4::Shutdown()
{
    //__HAL_RCC_TIM4_CLK_DISABLE();
    //HAL_NVIC_DisableIRQ(TIM4_IRQn);
}

void tim4::WakeUp()
{

}

void tim4::Sleep()
{

}

std::vector<unsigned char> tim4::Poll()
{
	std::vector<unsigned char> temp;
	return temp;
}

void tim4::SetPeriod(unsigned int period)
{
	if(period > 65000)
	{
		//Must be less than 65000
		while(1){};
	}
	else
	{
		_period = period;
	}
}

/*extern tim4 _tim4;

extern "C" void TIM4_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&_tim4._tim4);
}

extern "C" void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	HAL_TIM_Base_Stop_IT(&_tim4._tim4);
	_tim4._timeout = true;
	_tim4.Shutdown();
}*/
