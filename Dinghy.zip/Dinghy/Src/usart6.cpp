#include <usart6.h>

void usart6::Startup()
{
	__HAL_RCC_USART6_CLK_ENABLE();

	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF8_USART6;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	_uart.Instance = USART6;
	_uart.Init.BaudRate = 4800;
	_uart.Init.WordLength = UART_WORDLENGTH_8B;
	_uart.Init.StopBits = UART_STOPBITS_1;
	_uart.Init.Parity = UART_PARITY_NONE;
	_uart.Init.Mode = UART_MODE_TX_RX;
	_uart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	_uart.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&_uart);

	HAL_NVIC_SetPriority(USART6_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(USART6_IRQn);

	_ggamsg.push_back('$');
	_ggamsg.push_back('G');
	_ggamsg.push_back('P');
	_ggamsg.push_back('G');
	_ggamsg.push_back('G');
	_ggamsg.push_back('A');

	HAL_UART_Receive_IT(&_uart, &Rx_data, 1);

	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_RESET);
	HAL_Delay(500);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, GPIO_PIN_SET);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
	HAL_Delay(200);
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
	HAL_Delay(1000);
}

std::vector<unsigned char> usart6::stringtovec(std::string str)
{
	std::vector<unsigned char> temp;
	for(int i = 0; i < str.length(); i++)
	{
		temp.push_back(str.at(i));
	}
	return temp;
}

void usart6::Receive()
{
	if(recording)
	{
		if(Rx_data == '$')
		{
			result.clear();
			//Here we have a full GPGGA msg in _receivebuffer
			//Does it contain GPSData?
			if(_receivebuffer.size() > 45)
			{
				std::vector<unsigned char> commapos;
				for(int i = 0; i < _receivebuffer.size(); i++)
				{
					if(_receivebuffer.at(i) == ',')
					{
						commapos.push_back(i);
					}
				}
				//Check number of commas so we got all message
				if(commapos.size() > 13)
				{
					for(int j = 1; j < 6; j++)
					{
						//if the difference between the commas is bigger than 1 there is data
						if(commapos.at(j) - commapos.at(j-1) > 1)
						{

							result.insert(result.end(),_receivebuffer.begin() + commapos.at(j-1) + 1,_receivebuffer.begin() + commapos.at(j));
						}
						else if(j==1)
						{
							for(int i = 0; i < 10; i++)
							{
								result.push_back(0);
							}
						}
						else
						{
							result.clear();
							break;
						}
					}
				}
			}
			_receivebuffer.clear();
			recording = false;
		}
		else
		{
			_receivebuffer.push_back(Rx_data);
		}
	}
	else if(Rx_data == _ggamsg.at(pos))
	{
		pos++;
		if(pos == _ggamsg.size())
		{
			pos = 0;
			recording = true;
		}
	}
	HAL_UART_Receive_IT(&_uart, &Rx_data, 1);	//activate UART receive interrupt every time
}

void usart6::Shutdown()
{

}

void usart6::Sleep()
{

}

void usart6::WakeUp()
{

}

std::vector<unsigned char> usart6::Poll()
{
	std::vector<unsigned char> temp;

	if(result.size() > 1)
	{
		temp = result;
		result.clear();
	}
	else
	{
		for(int i = 0; i < 31; i++)
		{
			temp.push_back(0);
		}
	}

	return temp;
}

#ifdef DINGHY_MAIN
extern usart6 _usart6;

extern "C" void USART6_IRQHandler(void)
{
	HAL_UART_IRQHandler(&_usart6._uart);
}
#endif
