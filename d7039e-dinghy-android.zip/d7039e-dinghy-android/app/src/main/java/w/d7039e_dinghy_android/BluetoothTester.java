package w.d7039e_dinghy_android;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

import w.d7039e_dinghy_android.bluetooth.BluetoothHandler;
import w.d7039e_dinghy_android.bluetooth.IBluetoothActivity;
import w.d7039e_dinghy_android.dataprocessor.DataPreProcessor;
import w.d7039e_dinghy_android.logging.LoggerHandler;

public class BluetoothTester extends AppCompatActivity  implements IBluetoothActivity{
    BluetoothTester self;
    static TextView  textStatus;
    static TextView  textStatus2;
    static DataPreProcessor dataProcessor;
    static LoggerHandler loggerHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bluetooth_tester);
        self=this;
        dataProcessor = new DataPreProcessor();
        loggerHandler = new LoggerHandler(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getPath().toString(),this);
        loggerHandler.addNew();

        // Bluetooth
        final BluetoothHandler bluetoothHandler = new BluetoothHandler(this);


        textStatus = (TextView) findViewById(R.id.status_text);
        textStatus2 = (TextView) findViewById(R.id.status_text2);

        Button buttonSendMessage = (Button) findViewById(R.id.send_message_button);
        Button buttonTurnOn = (Button) findViewById(R.id.turn_on_button);
        Button buttonMakeParable = (Button) findViewById(R.id.pairable_button);
        Button buttonScan = (Button) findViewById(R.id.scan_button);
        Button buttonConnect = (Button) findViewById(R.id.connect_button);
        final Spinner sItems = (Spinner) findViewById(R.id.devices_spinner);
        final EditText message = (EditText) findViewById(R.id.send_message_text);




        // Button to access the feedback view
        assert buttonSendMessage != null;
        buttonSendMessage.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
                try {
                    bluetoothHandler.sendMessage(message.getText().toString());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        //
        assert buttonTurnOn != null;
        buttonTurnOn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
                textStatus.setText(bluetoothHandler.turnOn());
            }
        });
        //
        assert buttonMakeParable != null;
        buttonMakeParable.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
//                textStatus.setText(bluetoothHandler.visible());
            }
        });
        //
        assert buttonScan != null;
        buttonScan.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
                List<String> spinnerArray = bluetoothHandler.listDevices();
                spinnerArray.add("listen");
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(self, android.R.layout.simple_spinner_item, spinnerArray);

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                sItems.setAdapter(adapter);
            }
        });
        //
        assert buttonConnect != null;
        buttonConnect.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
                bluetoothHandler.connect(sItems.getSelectedItem().toString());

            }
        });

    }

    @Override
    public void reciveData(String data) {
        textStatus.setText(data);
    }

    @Override
    public void reciveData(byte[] encodedBytes) {
        DataPacket dp;
        for (byte b: encodedBytes) {
            dataProcessor.addByte(b);
            if(dataProcessor.nextDataPacketReady()){
                dp = dataProcessor.getNextDataPacket();
                loggerHandler.log(dp);
                textStatus2.setText(dp.toString());
            }
        }
    }
}
