package w.d7039e_dinghy_android;

import java.nio.ByteBuffer;
import java.util.ArrayList;

/**
 * Created by Mattias on 2016-09-07.
 */
public class DataPacket {
    public int time;
    public int pressure_center_board;
    public int strain_rudder;
    public int bat_main, bat_center_board, bat_rudder;
    public int height;
    public int magnetometer_x, magnetometer_y, magnetometer_z;
    public int accelerometer_x,accelerometer_y,accelerometer_z;
    public int gyroscope_x,gyroscope_y,gyroscope_z;
    public float latitude, longitude;
    public char latdir;
    public char longdir;


    public DataPacket(){

    };
    public DataPacket(ArrayList<Byte> bytes){
        time=(0x0ff&bytes.get(0))<<24;
        time+=(0x0ff&bytes.get(1))<<16;
        time+=(0x0ff&bytes.get(2))<<8;
        time+=(0x0ff&bytes.get(3));

        pressure_center_board=(0x0ff&bytes.get(4))<<8;
        pressure_center_board+=(0x0ff&bytes.get(5));

        strain_rudder = (0x0ff&bytes.get(6))<<8;
        strain_rudder+= (0x0ff&bytes.get(7));


        bat_main = (0x0ff&bytes.get(8))<<8;
        bat_main+=(0x0ff&bytes.get(9));
        bat_center_board = (0x0ff&bytes.get(10))<<8;
        bat_center_board += (0x0ff&bytes.get(11));
        bat_rudder = (0x0ff&bytes.get(12))<<8;
        bat_rudder += (0x0ff&bytes.get(13));

        height = (0x0ff&bytes.get(14));

        magnetometer_x = (0x0ff&bytes.get(15))<<8;
        magnetometer_x += (0x0ff&bytes.get(16));
        magnetometer_y = (0x0ff&bytes.get(17))<<8;
        magnetometer_y += (0x0ff&bytes.get(18));
        magnetometer_z = (0x0ff&bytes.get(19))<<8;
        magnetometer_z += (0x0ff&bytes.get(20));

        accelerometer_x = (0x0ff&bytes.get(21))<<8;
        accelerometer_x += (0x0ff&bytes.get(22));
        accelerometer_y = (0x0ff&bytes.get(23))<<8;
        accelerometer_y += (0x0ff&bytes.get(24));
        accelerometer_z = (0x0ff&bytes.get(25))<<8;
        accelerometer_z += (0x0ff&bytes.get(26));

        gyroscope_x = (0x0ff&bytes.get(27))<<8;
        gyroscope_x += (0x0ff&bytes.get(28));
        gyroscope_y = (0x0ff&bytes.get(29))<<8;
        gyroscope_y += (0x0ff&bytes.get(30));
        gyroscope_z = (0x0ff&bytes.get(31))<<8;
        gyroscope_z += (0x0ff&bytes.get(32));

        byte[] tmp_bytes1 = {bytes.get(33),bytes.get(34),bytes.get(35),bytes.get(36)};
        latitude = ByteBuffer.wrap(tmp_bytes1).getFloat();
        latdir = (char)(bytes.get(37) & 0xFF);

        byte[] tmp_bytes2 = {bytes.get(38),bytes.get(39),bytes.get(40),bytes.get(41)};
        longitude = ByteBuffer.wrap(tmp_bytes2).getFloat();
        longdir = (char)(bytes.get(42) & 0xFF);

    }

    public String toString(){
        return "time: " + time + ", pcb: " + pressure_center_board +  ", sr: " + strain_rudder
                + ", bm: " + bat_main + ", bcb: " + bat_center_board + ", br: " + bat_rudder
                + ", height: " + height + ", mx: " + magnetometer_x + ", my: " + magnetometer_y + ", mz: " + magnetometer_z
                + ", ax: " + accelerometer_x + ", ay: " + accelerometer_y + ", az:" + accelerometer_z
                + ", gx: " + gyroscope_x + ", gy: " + gyroscope_y + ", gz:" + gyroscope_z
                + ", la: " + latitude + ", lad: " + latdir + ", lo: " + longitude + ", lod: " + longdir;
    }
}
