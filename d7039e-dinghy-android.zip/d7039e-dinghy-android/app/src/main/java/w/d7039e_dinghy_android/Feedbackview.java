package w.d7039e_dinghy_android;

import android.content.SharedPreferences;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Arrays;

import w.d7039e_dinghy_android.bluetooth.BluetoothHandler;
import w.d7039e_dinghy_android.bluetooth.IBluetoothActivity;
import w.d7039e_dinghy_android.dataprocessor.DataPreProcessor;
import w.d7039e_dinghy_android.logging.LoggerHandler;
import w.d7039e_dinghy_android.logging.Stopwatch;

public class Feedbackview extends AppCompatActivity implements IBluetoothActivity {

    static DataPreProcessor dataProcessor;
    static LoggerHandler loggerHandler;
    static BluetoothHandler bluetoothHandler;
    static ProgressBar connecting_progress_bar;
    static Button connect_button;
    static TextView connection_status_textView;
    static TextView battery_textView;
    EditText recive_message_editText;
    boolean isConnected = false;
    boolean isRecording = false;
    Thread _connection_thread;

    Stopwatch stopwatch;

    @Override
    protected void onPause() {
        super.onPause();
        //if(isConnected) bluetoothHandler.disconnect();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedbackview);

        stopwatch = new Stopwatch();


        // Logger
        loggerHandler = new LoggerHandler(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getPath().toString(),this);

        // Bluetooth
        bluetoothHandler = new BluetoothHandler(this);

        // DataProcessor
        dataProcessor = new DataPreProcessor();


        connect_button = (Button)findViewById(R.id.connect_button);
        final Button recording_button = (Button)findViewById(R.id.recording_button);

        connection_status_textView = (TextView)findViewById(R.id.connection_status_textView);
        final TextView recording_status_textView = (TextView)findViewById(R.id.recording_status_textView);
        battery_textView = (TextView) findViewById(R.id.battery_textView);
        recive_message_editText = (EditText)findViewById(R.id.recive_message_editText);


        // Button to connect to bluetooth
        assert connect_button != null;
        connect_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                final boolean[] connected = new boolean[1];
                final Handler handler = new Handler();
                if(!isConnected){
                    //connect to device

                    SharedPreferences SP = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
                    final String devicename = SP.getString("devicename", "NA");
                    System.out.println("Feedbackview.java -connect_button.setOnClick- Settings devicename: " + devicename);
//                    for(String s:bluetoothHandler.listDevices())
//                    {
//                        System.out.println("Feedbackview.java -connect_button.setOnClick- all devicenames: " +s);
//                    }
                    if (bluetoothHandler.listDevices().contains(devicename)) {

                        connect_button.setText("Connecting...");
                        connection_status_textView.setText("Connecting...");

                        _connection_thread = new Thread(new Runnable() {
                        public void run() {
                            System.out.println("Connecting n stuff");
                            handler.post(new Runnable() {
                                public void run() {
                                    connection_check(bluetoothHandler.connect(devicename));
                                }
                            });
                            System.out.println("Connecting complete");
                            }
                        });
                        _connection_thread.start();
                }
                } else {
                    bluetoothHandler.disconnect();
                    connection_status_textView.setText("Not Connected");
                    connect_button.setText("Connect");
                    isConnected=false;
                }
            }
        });

        // Button to connect to bluetooth
        assert recording_button != null;
        recording_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(!isRecording){
                    recording_status_textView.setText("Recording");
                    recording_button.setText("Stop Recording");
                    loggerHandler.addNew();
                    stopwatch.start();
                    isRecording = true;
                } else {
                    recording_status_textView.setText("Not Recording");
                    recording_button.setText("Start Recording");
                    isRecording=false;
                    stopwatch.stop();
                }
            }
        });

    }

    public void connection_check(boolean connected){
        if (connected) {
            this.connection_status_textView.setText("Connected");
            connect_button.setText("Disconnect");
            isConnected = true;
        } else {
            connect_button.setText("Connect");
            connection_status_textView.setText("Failed Connection");
        }
    }

    @Override
    public void reciveData(String data) {

    }

    @Override
    public void reciveData(byte[] encodedBytes) {
        DataPacket dp;
        if(encodedBytes.length>0) {
            String s="";
            byte messageType = encodedBytes[0];
            switch (messageType) {
                case 2:
                    byte[] _encodedBytesUpper = stopwatch.lookup_time_bytes();
                    dataProcessor.addByteArray(_encodedBytesUpper);
                    byte[] _encodedBytesLower = Arrays.copyOfRange(encodedBytes, 2, encodedBytes.length);
                    dataProcessor.addByteArray(_encodedBytesLower);
                    dp = dataProcessor.getNextDataPacket();
                    if (isRecording) {
                        loggerHandler.log(dp);
                    }
                    String batery = "Main: "+(dp.bat_main-2850)/1150+"% Center Board: "+(dp.bat_center_board-2850)/1150+"% Rudder: "+(dp.bat_rudder-2850)/1150+"%";
                    System.out.println(batery);
                    battery_textView.setText(batery);
                    s=dp.toString();
                    recive_message_editText.setText(s);
                    break;
                default:
                    s+="Received unhandled message type: " + messageType;
                    recive_message_editText.setText(s);
            }
        }
        /*
        for (byte b: encodedBytes) {
            dataProcessor.addByte(b);
            if(dataProcessor.nextDataPacketReady()){
                dp = dataProcessor.getNextDataPacket();
                loggerHandler.log(dp);
                recive_message_editText.setText(dp.toString());
            }
        }
        */
    }

    private String charArrayToString(byte[] encodedBytes) {
        String result = "[ ";
        boolean first = true;
        for (byte b: encodedBytes) {
            if(first){
                result+=(char)b;
                first = false;
            } else {
                result+=", "+ (char)b;
            }
        }
        return  result+" ]";
    }
}
