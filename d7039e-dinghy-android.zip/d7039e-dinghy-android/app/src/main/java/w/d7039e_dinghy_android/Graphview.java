package w.d7039e_dinghy_android;

import android.os.Build;
import android.os.Environment;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import w.d7039e_dinghy_android.dataprocessor.DataPostProcessor;
import w.d7039e_dinghy_android.dataprocessor.DataPreProcessor;
import w.d7039e_dinghy_android.dataprocessor.EKF;
import w.d7039e_dinghy_android.dummydata.DummyDataGenerator;
import w.d7039e_dinghy_android.logging.Logger;
import w.d7039e_dinghy_android.logging.LoggerHandler;

public class Graphview extends AppCompatActivity {

    LoggerHandler loggerHandler;
    DataPostProcessor dpp;
    EKF ekf;

    // Dictionary to ids
    private final static LinkedHashMap<String, Integer> graph_ids = new LinkedHashMap<String, Integer>();
    static {
        graph_ids.put("pcb", R.id.pcb_graph);
        graph_ids.put("sr", R.id.sr_graph);
        graph_ids.put("bat_main", R.id.bat_main_graph);
        graph_ids.put("bat_rudder", R.id.bat_rudder_graph);
        graph_ids.put("h", R.id.h_graph);
        graph_ids.put("mx", R.id.mx_graph);
        graph_ids.put("my", R.id.my_graph);
        graph_ids.put("mz", R.id.mz_graph);
        graph_ids.put("ax", R.id.ax_graph);
        graph_ids.put("ay", R.id.ay_graph);
        graph_ids.put("az", R.id.az_graph);
        graph_ids.put("gx", R.id.gx_graph);
        graph_ids.put("gy", R.id.gy_graph);
        graph_ids.put("gz", R.id.gz_graph);

        graph_ids.put("displacement", R.id.displacement_graph);
        graph_ids.put("ekfx", R.id.ekfx_graph);
        graph_ids.put("ekfy", R.id.ekfy_graph);


    };

    // graph titles, labels and legend text
    private final static LinkedHashMap<String, String[]> graph_text = new LinkedHashMap<String,String[]>();
    static {
        graph_text.put("pcb", new String[]{"xAxis", "yAxis", "title1", "legend"});
        graph_text.put("sr", new String[]{"xAxis", "yAxis", "title2","legend"});
        graph_text.put("bat_main", new String[]{"xAxis", "yAxis", "title3","legend"});
        graph_text.put("bat_rudder", new String[]{"xAxis", "yAxis", "title4","legend"});
        graph_text.put("h", new String[]{"xAxis", "yAxis", "title5","legend"});
        graph_text.put("mx", new String[]{"xAxis", "yAxis", "title6","legend"});
        graph_text.put("my", new String[]{"xAxis", "yAxis", "title7","legend"});
        graph_text.put("mz", new String[]{"xAxis", "yAxis", "title8","legend"});
        graph_text.put("ax", new String[]{"xAxis", "yAxis", "title9","legend"});
        graph_text.put("ay", new String[]{"xAxis", "yAxis", "title10","legend"});
        graph_text.put("az", new String[]{"xAxis", "yAxis", "title10","legend"});
        graph_text.put("gx", new String[]{"xAxis", "yAxis", "title9","legend"});
        graph_text.put("gy", new String[]{"xAxis", "yAxis", "title10","legend"});
        graph_text.put("gz", new String[]{"xAxis", "yAxis", "title10","legend"});

        graph_text.put("displacement", new String[]{"xAxis", "yAxis", "title10","legend"});

        graph_text.put("ekfx", new String[]{"xAxis", "yAxis", "title10","legend"});
        graph_text.put("ekfy", new String[]{"xAxis", "yAxis", "title10","legend"});
    };

    // graph view object
    public LinkedHashMap<String, GraphView> graph_list = new LinkedHashMap<String,GraphView>();

    // select element in graph id list (UNUSED)
    int select;
    // / Dummy data
    int[] x;
    int[] y;



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        dpp = new DataPostProcessor();
        ekf = new EKF();
        setContentView(R.layout.activity_graphview);


        final Button log_select_button = (Button)findViewById(R.id.log_select_button);
        final Spinner log_spinner = (Spinner)findViewById(R.id.log_spinner);
        // populates graph_list
        try {
            initGraphViews();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Testing section 2

        String[] perms = {"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
        int permsRequestCode = 200;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) requestPermissions(perms, permsRequestCode);
        loggerHandler = new LoggerHandler(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).getPath().toString(),this);

        List<String> spinnerArray = loggerHandler.getLoggerNames();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        log_spinner.setAdapter(adapter);


        //
        assert log_select_button != null;
        log_select_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
                loggerHandler.selectLogger(log_spinner.getSelectedItem().toString());
                populateGraphFromLog();

            }
        });

     //   x = new int[dataPacketList.length];
     //   y = new int[dataPacketList.length];
     //   for (int i = 0; i<dataPacketList.length-1;i++){
    //        x[i] = dataPacketList[i].time;
     //  //    y[i] = dataPacketList[i].pitch;
      //  }


       // populateGraph(x,y,"Example1");
      // graphVisibility(true,"Example1");

    }

    private void populateGraphFromLog() {
        DataPacket[] data = loggerHandler.getLogData();
        int size = data.length;
        int time[] = new int[size];
        int pcb[] = new int[size];
        int sr[] = new int[size];
        int bat_main[] = new int[size];
        int bat_rudder[] = new int[size];
        int h[] = new int[size];

        int mx[] = new int[size];
        int my[] = new int[size];
        int mz[] = new int[size];

        int ax[] = new int[size];
        int ay[] = new int[size];
        int az[] = new int[size];

        int gx[] = new int[size];
        int gy[] = new int[size];
        int gz[] = new int[size];

        ArrayList<Double> tmpList1 = new ArrayList<>();
        ArrayList<Double> tmpList2 = new ArrayList<>();

        ArrayList<Double> xList = new ArrayList<>();
        ArrayList<Double> yList = new ArrayList<>();

        int displacement[] = new int[size];
        int ekfx[] =  new int[size];
        int ekfy[] = new int [size];


        int i = 0;
        for (DataPacket dp:data) {
            System.out.println(dp);

            time[i] = i;//dp.time;
            pcb[i] = dp.pressure_center_board;
            sr[i] = dp.strain_rudder;
            bat_main[i] = dp.bat_main;
            bat_rudder[i] = dp.bat_rudder;
            h[i] = dp.height;

            mx[i] = dp.magnetometer_x;
            my[i] = dp.magnetometer_y;
            mz[i] = dp.magnetometer_z;

            ax[i] = dp.accelerometer_x ;
            ay[i] = dp.accelerometer_y;
            az[i] = dp.accelerometer_z;

            gx[i] = dp.gyroscope_x;
            gy[i] = dp.gyroscope_y;
            gz[i] = dp.gyroscope_z;

            xList.add((double)dp.longitude);
            yList.add((double)dp.latitude);

            i++;

        }

        populateGraph(time,pcb,"pcb");
        populateGraph(time,sr,"sr");
        populateGraph(time,bat_main,"bat_main");
        populateGraph(time,bat_rudder,"bat_rudder");
        populateGraph(time,h,"h");
        populateGraph(time,mx,"mx");
        populateGraph(time,my,"my");
        populateGraph(time,mz,"mz");
        populateGraph(time,ax,"ax");
        populateGraph(time,ay,"ay");
        populateGraph(time,az,"az");
        populateGraph(time,gx,"gx");
        populateGraph(time,gy,"gy");
        populateGraph(time,gz,"gz");

        // UGLY AF
        dpp.convertGPS2distance(yList,xList);
        for(int k = 0; k<dpp.getDistanceArray().size(); k++) {
            displacement[k] = (int)dpp.getDistanceElement(k);

        }
        populateGraph(time,displacement,"displacement");

        //  UGLY AF------------------------------------------------------------------------
        dpp.convertGPS2cartesian(yList,xList);
        int tmp;
        for(int k = 0; k<dpp.getdxArray().size(); k++) {
            tmp = ax[k];
            tmpList1.add((double)tmp);
            tmp = ay[k];
            tmpList2.add((double)tmp);

        }
        ekf.runKalmanFilter(dpp.getdxArray(),dpp.getdyArray(),tmpList1,tmpList2,1);

        for(int k = 0; k<dpp.getdxArray().size(); k++) {
           ekfx[k] = (int)ekf.getposxElement(k);
           ekfy[k] = (int)ekf.getposyElement(k);
        }
        populateGraph(time,ekfx,"ekfx");
        populateGraph(time,ekfx,"ekfy");

        //-----------------------------------------------------------------------------------


    }


    // Init function for graphs
    public void initGraphViews() throws Exception{
        int length = graph_ids.size();
        Set<String> keys = graph_ids.keySet();
        GraphView graph;
        for (String key:keys) {
            graph = (GraphView) findViewById(graph_ids.get(key));
            if(graph!=null) graph_list.put(key, graph);
            else {
                System.out.println("Did not find graph with name: " + key);
                throw new Exception("Did not find graph with name: " + key);
            }

        }
    }

    // Places data into a certain graph with x and y data set
    public void populateGraph(int[] dataX, int[] dataY, String selectGraph){
        System.out.println("Populating " + selectGraph);
        GraphView graph = graph_list.get(selectGraph);
        if(null != graph) {
            LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
            for (int i = 0; i < dataX.length; i++) {
                series.appendData(new DataPoint(dataX[i], dataY[i]), true, dataX.length);
            }
            graph.removeAllSeries();
            graph.addSeries(series);
            //graphTitle(graph, graph_text.get(selectGraph)[2]);
            //GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
            //gridLabel.setHorizontalAxisTitle(graph_text.get(selectGraph)[0]);
            //gridLabel.setVerticalAxisTitle(graph_text.get(selectGraph)[1]);
            //series.setTitle(graph_text.get(selectGraph)[3]);
            //graph.getLegendRenderer().setVisible(true);
            //graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
            //graph.getViewport().setScrollable(true);
        }
    }

    // Places data into a certain graph with x and y data set
    public void populateGraph(double[] dataX, double[] dataY, String selectGraph){
        System.out.println("Populating " + selectGraph);
        GraphView graph = graph_list.get(selectGraph);
        if(null != graph) {
            LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
            for (int i = 0; i < dataX.length; i++) {
                series.appendData(new DataPoint(dataX[i], dataY[i]), true, dataX.length);
            }
            graph.removeAllSeries();
            graph.addSeries(series);
            //graphTitle(graph, graph_text.get(selectGraph)[2]);
            //GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
            //gridLabel.setHorizontalAxisTitle(graph_text.get(selectGraph)[0]);
            //gridLabel.setVerticalAxisTitle(graph_text.get(selectGraph)[1]);
            //series.setTitle(graph_text.get(selectGraph)[3]);
            //graph.getLegendRenderer().setVisible(true);
            //graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
            //graph.getViewport().setScrollable(true);
        }
    }

    // Places data into a certain graph with x and y data set
    public void populateGraph(ArrayList<Double> dataX, ArrayList<Double> dataY, String selectGraph){
        System.out.println("Populating " + selectGraph);
        GraphView graph = graph_list.get(selectGraph);
        if(null != graph) {
            LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
            int size = dataX.size();
            for (int i = 0; i < size; i++) {
                series.appendData(new DataPoint(dataX.get(i), dataY.get(i)), true, size);
            }
            graph.removeAllSeries();
            graph.addSeries(series);
            //graphTitle(graph, graph_text.get(selectGraph)[2]);
            //GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
            //gridLabel.setHorizontalAxisTitle(graph_text.get(selectGraph)[0]);
            //gridLabel.setVerticalAxisTitle(graph_text.get(selectGraph)[1]);
            //series.setTitle(graph_text.get(selectGraph)[3]);
            //graph.getLegendRenderer().setVisible(true);
            //graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
            //graph.getViewport().setScrollable(true);
        }
    }

    // Set visibility of a certain graph
    public void graphVisibility(boolean on, String selectGraph){
        // Set visibility of a certain graph
        GraphView graph = graph_list.get(selectGraph);
        if (on != true)
            graph.setVisibility(View.GONE);
        else
            graph.setVisibility(View.VISIBLE);
    }

    // get series function and a legend name
    public LineGraphSeries<DataPoint> getSeries(int[] dataX, int[] dataY, String legend){
        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
        for (int i = 0; i<dataX.length;i++){
            series.appendData(new DataPoint(dataX[i],dataY[i]),true,dataX.length);
        }
        if(legend != "") {
            series.setTitle(legend);
        }
        return series;
    }

    // Set graph title
    public void graphTitle(GraphView graph,String title){
        graph.setTitle(title);
    }

}











































//    // Choose the graph you want to be working with
//    public void chooseGraph(int select){
//        this.select = select;
//    }
//
//    // Name the axis on the graph
//    public void setLabelAxis(String xAxis, String yAxis, GraphView graph ){
//        GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
//        gridLabel.setHorizontalAxisTitle(xAxis);
//        gridLabel.setVerticalAxisTitle(yAxis);
//    }
//        GraphView graph = (GraphView) findViewById(R.id.graph);
//        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
//
//        double y,x;
//        x = 0;
//        y = 0;
//        for (int i = 0; i<500; i++){
//            x = x+0.1;
//            y = Math.sin(x);
//            series.appendData( new DataPoint(x,y), true, 500);
//        }
//        graph.addSeries(series);
//
//    }

//    public void displayData(int[] dataX, int[] dataY, int selectGraph){
//        GraphView graph = (GraphView) findViewById(graph_id[selectGraph-1]);
//        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();
//        for (int i = 0; i<dataX.length;i++){
//            series.appendData(new DataPoint(dataX[i],dataY[i]),true,dataX.length);
//        }
//        graph.addSeries(series);
//        // test section below
//        graphTitle(graph,"Title");
//    }


//        create/show(graphidentifier);
//        populategraph(graphidentifier, datax,datay);
//        destroyt/hide(graphidentifier);



//        // Testing section 1
//        // create a graph object
//        Graphview graphObject = new Graphview();
//        //Things you need to do in order to display graph
//        chooseGraph(1);
//        GraphView graph = (GraphView) findViewById(graph_id[select-1]);
//        graph.addSeries(graphObject.getSeries(x,x,"legend"));
//        graph.setTitle("Title");
//        // set labels of the x and y axis
//        GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
//        gridLabel.setHorizontalAxisTitle("X Axis Title");
//        gridLabel.setVerticalAxisTitle("Y Axis Title");
//        // Make the legend visible
//        graph.getLegendRenderer().setVisible(true);
//        graph.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
//
//        // Set visibility of a certain graph
//        //GraphView graph1 = (GraphView) findViewById(graph_id[select-1]);
//        //graph.setVisibility(View.GONE);
//        // set visibility to true
//         //graph.setVisibility(View.generateViewId());
