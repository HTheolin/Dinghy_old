package w.d7039e_dinghy_android;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //---------------------------------------------------- enter other views ----------------------
        // setup button functions for the main menu
        Button buttonFeedbackview = (Button)findViewById(R.id.feedbackviewButton);
        if (buttonFeedbackview != null) System.out.println("Feedback button " + buttonFeedbackview.getText());
        Button buttonGraphview = (Button)findViewById(R.id.graphviewButton);
        if (buttonGraphview != null) System.out.println("Graphview button " + buttonGraphview.getText());
        Button buttonStatview = (Button) findViewById(R.id.statviewButton);
        if (buttonStatview != null) System.out.println("Statview button " + buttonStatview.getText());
        Button buttonOptionview = (Button) findViewById(R.id.optionviewButton);
        if (buttonOptionview != null) System.out.println("Option button " + buttonOptionview.getText());
        Button buttonBluetoothview = (Button) findViewById(R.id.bluetooth_button);
        if (buttonBluetoothview != null) System.out.println("Bluetooth button " + buttonBluetoothview.getText());



        // Button to access the feedback view
        assert buttonFeedbackview != null;
        buttonFeedbackview.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // feedback button function
                startActivity(new Intent(MainActivity.this,Feedbackview.class));
            }
        });
        // Button to access the graph viewer
        assert buttonGraphview != null;
        buttonGraphview.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // graph view button function
                startActivity(new Intent(MainActivity.this,Graphview.class));
            }
        });
        // Button to access the stat viewer
        assert buttonStatview != null;
        buttonStatview.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // stat view button function
                startActivity(new Intent(MainActivity.this,Statview.class));
            }
        });
        //
        assert buttonOptionview != null;
        buttonOptionview.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // stat view button function
                startActivity(new Intent(MainActivity.this,Optionview.class));
            }
        });
        //
        assert buttonBluetoothview != null;
        buttonBluetoothview.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                // stat view button function
                startActivity(new Intent(MainActivity.this,BluetoothTester.class));
            }
        });
        //---------------------------------------------------- end ----------------------
    }
}
