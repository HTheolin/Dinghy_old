package w.d7039e_dinghy_android;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;

public class Statview extends AppCompatActivity {

    GridView gridView;
    // Create a static list
    // String[] statList = new String[] {
    //       "Average Speed", "", "Average Pitch", "", "Average Roll",
    //       "", "Average Yaw", "", "Distance Traveled", "","E1", "",
    //        "E2", "","E3", "","E4", ""};

    // Dynamic list
    ArrayList<String> statList = new ArrayList<String>();
    // unused
    public int nextElement;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statview);
        gridView = (GridView) findViewById(R.id.gridView);

        //Test Section

        addDummyData();
        populateGrid(gridView,statList);


    }


    public void populateGrid(GridView gridView, ArrayList<String> statList){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, statList);
        gridView.setAdapter(adapter);
    }

    public void addStat(String element, String data){
        statList.add(element);
        statList.add(data);
    }

    public void addDummyData(){
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
        addStat("E1","20m/s");
    }
}













//    public void findPosNext(String string) {
//        for (int i = 0; i < statList.size() - 1; i++) {
//            if (statList.get(i) == string){
//                nextElement = i+1;
//            }
//        }
//    }
//    public void addElementTostatList(String element){}