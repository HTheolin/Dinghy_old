package w.d7039e_dinghy_android.bluetooth;

import android.app.Activity;
import android.bluetooth.*;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.ParcelUuid;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import w.d7039e_dinghy_android.BluetoothTester;


/**
 * Created by Mattias on 2016-09-21.
 */
public class BluetoothHandler {
    BluetoothAdapter bluetoothAdapter;
    Activity activity;
    BluetoothSocket socket;
    BluetoothServerSocket serverSocker;
    IBluetoothActivity bluetoothActivity;
    private Set<BluetoothDevice> pairedDevices;
    Thread workerThread;
    volatile boolean stopWorker;
    byte[] readBuffer;
    int readBufferPosition;

    private OutputStream outputStream;
    public InputStream inStream;

    public boolean listening;

    public BluetoothHandler(Activity a){
        activity=a;
        bluetoothActivity =(IBluetoothActivity) a;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            String[] perms = {"android.permission.BLUETOOTH"};
            int permsRequestCode = 200;
            activity.requestPermissions(perms, permsRequestCode);
        }

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(bluetoothAdapter != null)
        {
            if (bluetoothAdapter.isEnabled()) {
                // Enabled. Work with Bluetooth.
            }
            else
            {

            }
        }
    }

    public String turnOn(){
        if(!bluetoothAdapter.isEnabled()){
            Intent turnOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            activity.startActivityForResult(turnOn,0);
            return "Turned On";
        } else {
            return "Already On";
        }
    }

    public String turnOff(){
        bluetoothAdapter.disable();
        return "Turned Off";
    }

    public String visible(){
        Intent getVisible = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        activity.startActivityForResult(getVisible, 0);
        return "Visible";
    }

    public List<String> listDevices(){
        pairedDevices= bluetoothAdapter.getBondedDevices();
        ArrayList list = new ArrayList();

        List<String> devices = new ArrayList<String>();

        for(BluetoothDevice bt: pairedDevices){
            devices.add(bt.getName());
        }
        return devices;
    }

    public BluetoothDevice getDevice(String deviceName){
        pairedDevices= bluetoothAdapter.getBondedDevices();
        ArrayList list = new ArrayList();

        List<String> devices = new ArrayList<String>();

        System.out.println("bluetooth.BluetoothHandler.java -getDevice(String deviceName)- DeviceName: " + deviceName);
        for(BluetoothDevice bt: pairedDevices){
            if(bt.getName().equals(deviceName)){
                return bt;
            }
        }
        return null;
    }

    public void disconnect(){
        stopWorker = true;
        if (inStream != null) {
            try {inStream.close();} catch (Exception e) {}
            inStream = null;
        }

        if (outputStream != null) {
            try {outputStream.close();} catch (Exception e) {}
            outputStream = null;
        }

        if (socket != null) {
            try {socket.close();} catch (Exception e) {}
            socket = null;
        }
    }

    public boolean connect(String deviceName) {

        BluetoothDevice device = getDevice(deviceName);
        if(device==null)return false;
        ParcelUuid[] uuids = device.getUuids();

        if(deviceName=="listen"){
            try {
                serverSocker = bluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord("BluetoothServer",UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                socket = serverSocker.accept();
                outputStream=socket.getOutputStream();
                inStream=socket.getInputStream();
                listening=true;
                beginListenForData();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        } else {
            try {
                socket = device.createInsecureRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                socket.connect();
                outputStream=socket.getOutputStream();
                inStream=socket.getInputStream();
                listening=true;
                beginListenForData();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        }

    }

    public void sendMessage(String text) throws IOException {
        outputStream.write(text.getBytes());
    }

    void beginListenForData()
    {
        final Handler handler = new Handler();
        final byte delimiter = 10; //This is the ASCII code for a newline character

        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];
        final int message_size = 62;
        workerThread = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopWorker)
                {
                    try
                    {
                        int bytesAvailable = inStream.available();
                        if(bytesAvailable >= message_size)
                        {
                            inStream.read(readBuffer,0,message_size);
                            final byte[] encodedBytes = new byte[message_size];
                            System.arraycopy(readBuffer, 0, encodedBytes, 0, message_size);
                            final String data = new String(encodedBytes, "US-ASCII");
                            readBufferPosition = 0;

                            handler.post(new Runnable() {
                                public void run() {
                                    bluetoothActivity.reciveData(encodedBytes);
                                    bluetoothActivity.reciveData(data);
                                }
                            });
                        }
                    }
                    catch (IOException ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }
}
