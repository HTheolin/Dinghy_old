package w.d7039e_dinghy_android.bluetooth;

/**
 * Created by Mattias on 2016-10-13.
 */
public interface IBluetoothActivity {
    public void reciveData(String data);

    public void reciveData(byte[] encodedBytes);
}
