package w.d7039e_dinghy_android.dataprocessor;

/**
 * Created by Alexander Örneskans on 2016-11-25.
 */

import java.util.ArrayList;
import java.lang.Math; // headers MUST be above the first class

import w.d7039e_dinghy_android.DataPacket;

/**
 * Created by Admin on 2016-11-23.
 */
public class DataPostProcessor {
    final int R = 6371000; // Radius of the earth in meters

    ArrayList<Double> resultantDistance = new ArrayList<Double>(); // resultant data points of distance

    // These two arrays stores the cartesian coordiantes of the longitude and latitude
    ArrayList<Double> dxData = new ArrayList<Double>();
    ArrayList<Double> dyData = new ArrayList<Double>();
    DataPacket[] dataPackets;

    double dx = 0;
    double dy = 0;

    public ArrayList<Double> getDistanceArray(){
        return resultantDistance;
    }

    public double getDistanceElement(int i){
        return resultantDistance.get(i);
    }


    public ArrayList<Double> getdxArray(){
        return dxData;
    }
    public ArrayList<Double> getdyArray(){
        return dyData;
    }

    //public DataPostProcessor(DataPacket[] dps){
  //      dataPackets = dps;
  //  }

    // Converts an array of doubles with longitude and latitude data into resultant distances
    public void  convertGPS2distance(ArrayList<Double> latList, ArrayList<Double> longList){

        for(int i = 0; i<latList.size()-1;i++){
            haversineFormula(longList.get(i), longList.get(i + 1), latList.get(i), latList.get(i + 1));
        }
    }

    // Converts an array of doubles containing longitude and latitude data into cartesian coordiantes
    public void convertGPS2cartesian(ArrayList<Double> latList, ArrayList<Double> longList){

        for(int i = 0; i<latList.size()-1;i++){
            gps2xy(longList.get(i), longList.get(i + 1), latList.get(i), latList.get(i + 1));
        }
    }


    // for x y Cartesian coords (this is the mathematical formula) spits out in meters
    // This is called Equilateral projection and works only well when you dont move great distances
    public void gps2xy(double long1, double long2, double lat1, double lat2){

        dx = (toRad(long2-long1)) * Math.cos(toRad((lat1+lat2)/2));
        dy = (toRad(lat2-lat1));

        dxData.add(dx*R);
        dyData.add(dy*R);


    }


    // actual distance travelled (mathematical formula)
    // Can be used with filtering but with resultant speeds and accelerations
    public void haversineFormula(double long1, double long2, double lat1, double lat2){

        double d = 2*R*Math.asin(Math.sqrt(hav(toRad(lat2-lat1)) +
                Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*hav(toRad(long2-long1))));
        resultantDistance.add(d);
    }


    // Converts degrees into rads (mathematical formula)
    public double toRad(double value) {
        return value * Math.PI / 180;
    }

    public double hav(double theta){
        return (1-Math.cos(theta))/2;
    }


}
