package w.d7039e_dinghy_android.dataprocessor;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import w.d7039e_dinghy_android.DataPacket;

/**
 * Created by Mattias on 2016-10-24.
 */
public class DataPreProcessor {
    byte previusByte;
    boolean next;

    private ArrayList<Byte> inBytes;
    private int messageLength; // Number of bytes of each message

    public DataPreProcessor(){
        inBytes = new ArrayList<>();
        messageLength = 10;
        previusByte = 0;
        next=false;
    }

    public void addByte(byte b){
        System.out.println("["+b+"]");
        inBytes.add(b);
        next = (b==13) || next;
    }

    private void processMessage() {
        //Implement later
    }

    public boolean nextDataPacketReady() {
        return next;
    }

    public DataPacket getNextDataPacket() {
        ArrayList<Byte> data = new ArrayList<>();

        String tmp_string;
        List<Byte> tmp_byte_list;
        byte[] tmp_byte_array;
        float tmp_float;

        System.out.println("size: "+inBytes.size());

        if(inBytes.size()>=64){
            next=false;
            for(int i = 0;i<33;i++){
                data.add(inBytes.get(i));
            }
            tmp_byte_list = inBytes.subList(43,52);
            tmp_string = byteListToString(tmp_byte_list, Charset.defaultCharset());//tmp_byte_list.toString();
            try{
                tmp_float = Float.parseFloat(tmp_string);
                tmp_byte_array = ByteBuffer.allocate(4).putFloat(tmp_float).array();
                for(byte b : tmp_byte_array){
                    data.add(b);
                }
            }catch (NumberFormatException e){
                tmp_float = 0.0f;
                tmp_byte_array = ByteBuffer.allocate(4).putFloat(tmp_float).array();
                for(byte b : tmp_byte_array){
                    data.add(b);
                }
                System.out.println("DataPreProcessor.java -- getNextDataPacker() :: failed to format float");
            }
            data.add(inBytes.get(52));

            tmp_byte_list = inBytes.subList(53,63);
            tmp_string = byteListToString(tmp_byte_list, Charset.defaultCharset());//tmp_byte_list.toString();
            try{
                tmp_float = Float.parseFloat(tmp_string);
                tmp_byte_array = ByteBuffer.allocate(4).putFloat(tmp_float).array();
                for (byte b : tmp_byte_array) {
                    data.add(b);
                }
            } catch (NumberFormatException e){
                tmp_float = 0.0f;
                tmp_byte_array = ByteBuffer.allocate(4).putFloat(tmp_float).array();
                for(byte b : tmp_byte_array){
                    data.add(b);
                }
                System.out.println("DataPreProcessor.java -- getNextDataPacker() :: failed to format float");
            }
            data.add(inBytes.get(63));

            //System.out.println("Data to dp[ size: "+data.size() + ", data: " + data.toString() + " ]");
            DataPacket dp = new DataPacket(data);
            inBytes.clear();
            return dp;
        }
        return new DataPacket();

    }

    public void addByteArray(byte[] data) {
        for (byte b:data) {
            inBytes.add(b);
        }
    }

    public static String byteListToString(List<Byte> l, Charset charset) {
        if (l == null) {
            return "";
        }
        byte[] array = new byte[l.size()];
        int i = 0;
        for (Byte current : l) {
            array[i] = current;
            i++;
        }
        String s = new String(array, charset);
        //System.out.println("From: " + array.toString() +"\nTo: " + s);
        return s;
    }
}
