package w.d7039e_dinghy_android.dataprocessor;
import java.util.ArrayList;

/**
 * Created by Alexander Örnesknas on 2016-11-28.
 * This is a Extended kalman filter that predicts position in x and y directions
 * Create a instance of the EKF
 * input a list of data using doubles into the runKalmanFilter
 * Extract postXhat, PosYhat, accXhat etc from the object in order to get a list of estimated data
 *
 * EKF ekf = new EKF();
 *
 * ekf.runKalmanFilter(positionX,positionY,accelerationX,accelertaionY)
 *
 * ------ extracting data
 * ekf.(some array name)
 *
 */
public class EKF {

    ArrayList<Double> posXhat = new ArrayList<Double>();
    ArrayList<Double> posYhat = new ArrayList<Double>();
    ArrayList<Double> accXhat = new ArrayList<Double>();
    ArrayList<Double> accYhat = new ArrayList<Double>();




    public double getposxElement(int i){
        return posXhat.get(i);
    }
    public double getposyElement(int i){
        return posYhat.get(i);
    }

    public void run1DKalmanFilter(ArrayList<Double> pos, ArrayList<Double> acc,float samplingTime){

        // This is the sampling time
        float dT = samplingTime;
        // This is the A Matrix
        // Includes motion in the x and y directions
        final double[][] a = {{1,dT,0.5*dT*dT},{0,1,dT},{0,0,1}};
        // This is the measurement matrix
        final double[][] c = {{0.5,0,0},{0,0,0},{0,0,1}};
        // Initial P matrix
        double[][] p = {{1.3945,0.2104,0.0112},{0.2104,0.1070,0.0072},{0.0112,0.0072,0.0016}};
        // Process noise Q
        double [][] q = {{0.2,0.5,0},{0,0.1,0},{0,0,0.01}};
        // Sensor noise R
        double [][] r = {{6,0,0},{0,0.1,0},{0,0,0.4}};
        // state variable xv
        double [][] xv = {{0},{0},{0}};
        // Kalman matrix
        double [][] k = {{0,0,0,},{0,0,0},{0,0,0}};
        // Var zm measured variables
        double [][] zm =  {{0},{0},{0}};
        // Var zhat measured variables
        double [][] zhat =  {{0},{0},{0}};

        Matrix A = new Matrix(a);
        Matrix C = new Matrix(c);
        Matrix P = new Matrix(p);
        Matrix Q = new Matrix(q);
        Matrix R = new Matrix(r);
        Matrix x = new Matrix(xv);
        Matrix K = new Matrix(k);
        Matrix Zm = new Matrix(zm);
        Matrix Zhat = new Matrix(zhat);
        Matrix I = new Matrix (p);


        for(int i = 0; i < acc.size();i++){

            // Update the measurement matrix for each time interval with input data.
            Zm = Zm.updateMeasurementMatrix(pos,acc, i);
            // Time update
            x = A.times(x);
            P = (A.times(P).times(A.transpose())).plus(Q);
            // Measurement update
            K = (P.times(C.transpose())).times(((C.times(P).times(C.transpose())).plus(R)).scale(0.1));
            x = x.plus((K.times((Zm.minus(C.times(x))))));
            P = I.minus((K.times(C))).times(P);
            // Prediction
            Zhat = C.times(x);
            //System.out.println("-------------------------------");
            //Zhat.show();

            posXhat.add(Zhat.getPredictionArray().get(0));
            accXhat.add(Zhat.getPredictionArray().get(2));
        }
    }

    public void runKalmanFilter(ArrayList<Double> posX, ArrayList<Double> posY, ArrayList<Double> accX, ArrayList<Double> accY, float samplingTime) {

        // This is the sampling time
        float dT = samplingTime;
        // This is the A Matrix
        // Includes motion in the x and y directions
        final double[][] a = {{1,dT,0.5*dT*dT,0,0,0},{0,1,dT,0,0,0},{0,0,1,0,0,0},{0,0,0,1,dT,0.5*dT*dT},{0,0,0,0,1,dT},{0,0,0,0,0,1}};
        // This is the measurement matrix
        final double[][] c = {{0.5,0,0,0,0,0},{0,0,0,0,0,0},{0,0,1,0,0,0},{0,0,0,0.5,0,0},{0,0,0,0,0,0},{0,0,0,0,0,1}};
        // Initial P matrix
        double[][] p = {{1.3945,0.2104,0.0112,0,0,0},{0.2104,0.1070,0.0072,0,0,0},{0.0112,0.0072,0.0016,0,0,0},{0,0,0,1.3945,0.2104,0.0112},{0,0,0,0.2104,0.1070,0.0072},{0,0,0,1.3945,0.2104,0.0112}};
        // Process noise Q
        double [][] q = {{0.2,0.5,0,0,0,0},{0,0.1,0,0,0,0},{0,0,0.01,0,0,0},{0,0,0,0.2,0.5,0},{0,0,0,0,0.1,0},{0,0,0,0,0,0,0.01}};
        // Sensor noise R
        double [][] r = {{6,0,0,0,0,0},{0,0.1,0,0,0,0},{0,0,0.4,0,0,0},{0,0,0,6,0,0},{0,0,0,0,0.1,0},{0,0,0,0,0,0.4}};
        // state variable xv
        double [][] xv = {{0},{0},{0},{0},{0},{0}};
        // Kalman matrix
        double [][] k = {{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};
        // Var zm measured variables
        double [][] zm =  {{0},{0},{0},{0},{0},{0}};
        // Var zhat measured variables
        double [][] zhat =  {{0},{0},{0},{0},{0},{0}};

        Matrix A = new Matrix(a);
        Matrix C = new Matrix(c);
        Matrix P = new Matrix(p);
        Matrix Q = new Matrix(q);
        Matrix R = new Matrix(r);
        Matrix x = new Matrix(xv);
        Matrix K = new Matrix(k);
        Matrix Zm = new Matrix(zm);
        Matrix Zhat = new Matrix(zhat);
        Matrix I = new Matrix (p);


        for(int i = 0; i < accX.size();i++){

            // Update the measurement matrix for each time interval with input data.
            Zm = Zm.fullUpdateMeasurementMatrix(posX, posY,accX,accY, i);
            // Time update
            x = A.times(x);
            P = (A.times(P).times(A.transpose())).plus(Q);
            // Measurement update
            K = (P.times(C.transpose())).times(((C.times(P).times(C.transpose())).plus(R)).scale(0.1));
            x = x.plus((K.times((Zm.minus(C.times(x))))));
            P = I.minus((K.times(C))).times(P);
            // Prediction
            Zhat = C.times(x);
            //System.out.println("-------------------------------");
            //Zhat.show();


            posXhat.add(Zhat.getPredictionArray().get(0));
            posYhat.add(Zhat.getPredictionArray().get(3));
            accXhat.add(Zhat.getPredictionArray().get(2));
            accYhat.add(Zhat.getPredictionArray().get(5));



        }
    }
}






