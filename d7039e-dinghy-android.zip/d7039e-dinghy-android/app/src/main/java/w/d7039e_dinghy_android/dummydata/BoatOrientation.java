package w.d7039e_dinghy_android.dummydata;

/**
 * Created by Mattias on 2016-09-12.
 */

public enum BoatOrientation {
    LEAN_LEFT,LEAN_RIGHT,STRAIGHT
}
