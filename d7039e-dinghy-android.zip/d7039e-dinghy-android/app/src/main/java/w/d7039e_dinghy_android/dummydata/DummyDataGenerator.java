package w.d7039e_dinghy_android.dummydata;

import w.d7039e_dinghy_android.DataPacket;

import java.util.Random;

/**
 * Created by Mattias on 2016-09-12.
 */

public class DummyDataGenerator {
    private BoatOrientation boat_previus_orientation;
    private int time;
    private BoatOrientation boat_orientation;
    private int boat_orientation_progress;
    private int event_probability;
    private boolean letting_down_centerboard;
    private boolean pulling_up_centerboard;
    private int centerboardheight;

    private int x, y;

    private Random random;
    public DummyDataGenerator(){
        this.letting_down_centerboard = false;
        this.pulling_up_centerboard = false;
        this.centerboardheight = 0;
        this.time = 0;
        this.boat_orientation = BoatOrientation.STRAIGHT;
        this.boat_previus_orientation = BoatOrientation.STRAIGHT;
        this.boat_orientation_progress = 0;
        this.event_probability = 0;
        this.random = new Random();
        this.x = 0;
        this.y = 0;

    }

    public DataPacket generateDataPacket(){
        if(this.event_probability > random.nextInt(130)){
            doEvent();
        }
        if(this.event_probability < 100)this.event_probability += 1;

        DataPacket dp = new DataPacket();
/*
        dp.pressure_v_rudder = getVRudder();
        dp.pressure_h_rudder = getHRudder();
        dp.pressure_v_center_board = getVCenter();
        dp.pressure_h_center_board = getHCenter();

        dp.longitude = getLongitude();
        dp.latitude = getLatitude();

        dp.pitch = getPitch();
        dp.yaw = getYaw();
        dp.roll = getRoll();

        dp.height = getHeight();

        dp.time = getTime();
*/
        return dp;
    }

    private void doEvent() {
//        System.out.println("New Event");
        this.event_probability = 0;
        switch (this.boat_orientation){
            case LEAN_LEFT:
                this.boat_orientation = BoatOrientation.STRAIGHT;
                break;
            case LEAN_RIGHT:
                this.boat_orientation = BoatOrientation.STRAIGHT;
                break;
            case STRAIGHT:
                if(random.nextBoolean()){
                    this.boat_orientation = BoatOrientation.LEAN_LEFT;
                } else {
                    this.boat_orientation = BoatOrientation.LEAN_RIGHT;
                }
                break;
            default:
                break;
        }
    }

    private int getVRudder() {
        int sensor;
        int noise = this.random.nextInt(10)-5;
        int diff = getPreasureDiff();

        switch(this.boat_orientation){
            case LEAN_LEFT:
                sensor = 128 - diff + noise;
                break;
            case LEAN_RIGHT:
                sensor = 128 + diff + noise;
                break;
            case STRAIGHT:
                sensor = 128 + noise;
                if(this.boat_previus_orientation == BoatOrientation.LEAN_LEFT){
                    sensor += diff;
                } else if(this.boat_previus_orientation == BoatOrientation.LEAN_RIGHT){
                    sensor -= diff;
                }
                break;
            default:
                sensor = 128;
                break;
        }
        return sensor;
    }

    private int getHRudder() {
        int sensor;
        int noise = this.random.nextInt(10)-5;
        int diff = getPreasureDiff();

        switch(this.boat_orientation){
            case LEAN_LEFT:
                sensor = 128 + diff + noise;
                break;
            case LEAN_RIGHT:
                sensor = 128 - diff + noise;
                break;
            case STRAIGHT:
                sensor = 128 + noise;
                if(this.boat_previus_orientation == BoatOrientation.LEAN_LEFT){
                    sensor -= diff;
                } else if(this.boat_previus_orientation == BoatOrientation.LEAN_RIGHT){
                    sensor += diff;
                }
                break;
            default:
                sensor = 128;
                break;
        }
        return sensor;
    }

    private int getVCenter() {
        int sensor;
        int noise = this.random.nextInt(10)-5;
        int diff = getPreasureDiff();

        switch(this.boat_orientation){
            case LEAN_LEFT:
                sensor = 128 - diff + noise;
                break;
            case LEAN_RIGHT:
                sensor = 128 + diff + noise;
                break;
            case STRAIGHT:
                sensor = 128 + noise;
                if(this.boat_previus_orientation == BoatOrientation.LEAN_LEFT){
                    sensor += diff;
                } else if(this.boat_previus_orientation == BoatOrientation.LEAN_RIGHT){
                    sensor -= diff;
                }
                break;
            default:
                sensor = 128;
                break;
        }
        return sensor;
    }

    private int getHCenter() {
        int sensor;
        int noise = this.random.nextInt(10)-5;
        int diff = getPreasureDiff();

        switch(this.boat_orientation){
            case LEAN_LEFT:
                sensor = 128 + diff + noise;
                break;
            case LEAN_RIGHT:
                sensor = 128 - diff + noise;
                break;
            case STRAIGHT:
                sensor = 128 + noise;
                if(this.boat_previus_orientation == BoatOrientation.LEAN_LEFT){
                    sensor -= diff;
                } else if(this.boat_previus_orientation == BoatOrientation.LEAN_RIGHT){
                    sensor += diff;
                }
                break;
            default:
                sensor = 128;
                break;
        }
        return sensor;
    }

    private int getLongitude() {
        return 0;
    }

    private int getLatitude() {
        return 0;
    }

    private int getPitch() {
        return 128 + random.nextInt(20)-10;
    }

    private int getYaw() {
        return 128 + random.nextInt(20)-10;
    }

    private int getRoll() {
        // 0 upside down
        // 64 90 degree to the left
        // 128 upside up
        // 192 90 degree to the right
        // 256 upside down

        int sensor;
        int noise = this.random.nextInt(4)-2;
        int diff = getAngleDiff();
        this.boat_orientation_progress += diff;
        if(this.boat_orientation_progress > 100){
            this.boat_orientation_progress = 100;
        }

        switch(this.boat_orientation){
            case LEAN_LEFT:
                sensor = 128 - this.boat_orientation_progress/100*38 + noise;
                break;
            case LEAN_RIGHT:
                sensor = 128 + this.boat_orientation_progress/100*38 + noise;
                break;
            case STRAIGHT:
                if(this.boat_previus_orientation == BoatOrientation.LEAN_LEFT){
                    sensor = 90 + this.boat_orientation_progress/100*38 + noise;
                } else if(this.boat_previus_orientation == BoatOrientation.LEAN_RIGHT){
                    sensor = 166 - this.boat_orientation_progress/100*38 + noise;
                } else {
                    sensor = 128 + noise;
                }
                break;
            default:
                sensor = 128;
                break;
        }
        return sensor;
    }



    private int getHeight() {
        // 0 is in water
        // 256 is out of water
        switch (this.boat_orientation){
            case LEAN_LEFT:
                this.pulling_up_centerboard = false;
                if(this.letting_down_centerboard){
                    this.centerboardheight -= this.random.nextInt(30)+45;
                    if(this.centerboardheight < 0){
                        this.letting_down_centerboard = false;
                        this.centerboardheight = 0;
                    }
                } else if (this.centerboardheight != 0) {
                    if(this.random.nextInt(50)>25){
                        this.letting_down_centerboard = true;
                    }
                }
                break;
            case LEAN_RIGHT:
                this.pulling_up_centerboard = false;
                if(this.letting_down_centerboard){
                    this.centerboardheight -= this.random.nextInt(30)+45;
                    if(this.centerboardheight < 0){
                        this.letting_down_centerboard = false;
                        this.centerboardheight = 0;
                    }
                } else if (this.centerboardheight != 0) {
                    if(this.random.nextInt(50)>25){
                        this.letting_down_centerboard = true;
                    }
                }
                break;
            case STRAIGHT:
                this.letting_down_centerboard = false;
                if(this.pulling_up_centerboard){
                    this.centerboardheight += this.random.nextInt(30)+45;
                    if(this.centerboardheight > 255){
                        this.pulling_up_centerboard = false;
                        this.centerboardheight = 255;
                    }
                } else if (this.centerboardheight != 0) {
                    if(this.random.nextInt(50)>25){
                        this.pulling_up_centerboard = true;
                    }
                }
                break;
            default:
                break;
        }
        return this.centerboardheight;
    }

    private int getTime(){
        int result = this.time;
        this.time += 500;
        return result;
    }

    private int getPreasureDiff(){
        int diff;
        if(this.boat_orientation_progress < 90 || this.boat_orientation_progress > 10){
            diff = this.random.nextInt(60)+60;
        } else if (this.boat_orientation_progress < 97 || this.boat_orientation_progress > 3) {
            diff = this.random.nextInt(30) +30;
        } else {
            diff = 0;
        }
        return diff;
    }

    private int getAngleDiff() {
        int diff;
        if(this.boat_orientation_progress < 90 || this.boat_orientation_progress > 10){
            diff = this.random.nextInt(10)+10;
        } else if (this.boat_orientation_progress < 97 || this.boat_orientation_progress > 3) {
            diff = this.random.nextInt(5) +5;
        } else {
            diff = 0;
        }
        return diff;
    }
}
