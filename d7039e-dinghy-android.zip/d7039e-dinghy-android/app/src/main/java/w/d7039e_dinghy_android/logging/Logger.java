package w.d7039e_dinghy_android.logging;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.ByteBuffer;

import w.d7039e_dinghy_android.DataPacket;

/**
 * Created by Mattias on 2016-09-06.
 */
public class Logger {
    private String session;
    private String dir;

    public Logger(String dir, String session){
        this.session = session;
        this. dir = dir;
    }

    // logs one data point. Called each time phone gets a data packet from main board.
    /*public void log(int[] dataIn) {
        if(dataIn.length == 11){
            DataPacket data = new DataPacket();

            data.time = dataIn[0];

            data.pressure_v_rudder = dataIn[1];
            data.pressure_h_rudder = dataIn[2];
            data.pressure_v_center_board = dataIn[3];
            data.pressure_h_center_board = dataIn[4];

            data.height = dataIn[5];

            data.pitch = dataIn[6];
            data.yaw = dataIn[7];
            data.roll = dataIn[8];

            data.longitude = dataIn[9];
            data.latitude = dataIn[10];

            log(data);
        }
    }*/

    // logs one data point. Called each time phone gets a data packet from main board.
    public void log(DataPacket data){
        //System.out.println("logging.Logger.java -- Logging dp: " + data);
        byte[] bytes = new byte[43];
//        System.out.println("Logger Data: "+data.toString());

        //region byte conversion
        byte[] tmp_bytes = intToByteArray(data.time);
        bytes[0] = tmp_bytes[3];
        bytes[1] = tmp_bytes[2];
        bytes[2] = tmp_bytes[1];
        bytes[3] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.pressure_center_board);
        bytes[4] = tmp_bytes[1];
        bytes[5] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.strain_rudder);
        bytes[6] = tmp_bytes[1];
        bytes[7] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.bat_main);
        bytes[8] = tmp_bytes[1];
        bytes[9] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.bat_center_board);
        bytes[10] = tmp_bytes[1];
        bytes[11] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.bat_rudder);
        bytes[12] = tmp_bytes[1];
        bytes[13] = tmp_bytes[0];

        bytes[14] = (byte)data.height;

        tmp_bytes = intToByteArray(data.magnetometer_x);
        bytes[15] = tmp_bytes[1];
        bytes[16] = tmp_bytes[0];
        tmp_bytes = intToByteArray(data.magnetometer_y);
        bytes[17] = tmp_bytes[1];
        bytes[18] = tmp_bytes[0];
        tmp_bytes = intToByteArray(data.magnetometer_z);
        bytes[19] = tmp_bytes[1];
        bytes[20] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.accelerometer_x);
        bytes[21] = tmp_bytes[1];
        bytes[22] = tmp_bytes[0];
        tmp_bytes = intToByteArray(data.accelerometer_y);
        bytes[23] = tmp_bytes[1];
        bytes[24] = tmp_bytes[0];
        tmp_bytes = intToByteArray(data.accelerometer_z);
        bytes[25] = tmp_bytes[1];
        bytes[26] = tmp_bytes[0];

        tmp_bytes = intToByteArray(data.gyroscope_x);
        bytes[27] = tmp_bytes[1];
        bytes[28] = tmp_bytes[0];
        tmp_bytes = intToByteArray(data.gyroscope_y);
        bytes[29] = tmp_bytes[1];
        bytes[30] = tmp_bytes[0];
        tmp_bytes = intToByteArray(data.gyroscope_z);
        bytes[31] = tmp_bytes[1];
        bytes[32] = tmp_bytes[0];

        tmp_bytes = ByteBuffer.allocate(4).putFloat(data.latitude).array();
        bytes[33] = tmp_bytes[0];
        bytes[34] = tmp_bytes[1];
        bytes[35] = tmp_bytes[2];
        bytes[36] = tmp_bytes[3];
        bytes[37] = (byte)data.latdir; // Here we might have the cause of a future error (might have to multiply by 0x0FF)

        tmp_bytes = ByteBuffer.allocate(4).putFloat(data.longitude).array();
        bytes[38] = tmp_bytes[0];
        bytes[39] = tmp_bytes[1];
        bytes[40] = tmp_bytes[2];
        bytes[41] = tmp_bytes[3];
        bytes[42] = (byte)data.longdir; // Here we might have the cause of a future error (might have to multiply by 0x0FF)


        try {
            FileOutputStream file = new FileOutputStream(this.dir + "/" + this.session, true);
            //System.out.println("logging.Logger.java -- Path to file: " + this.dir + "/" + this.session);
            file.write(bytes);
            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Get all data point from this log
    public DataPacket[] getDataSet() {
        System.out.println("Log getting data set");
        try {
            File dataFile = new File(this.dir + "/" + this.session);
            System.out.println("DataFile: " + dataFile.toString() + "\n Size: " + dataFile.length());
            int len = (int) dataFile.length();
            byte[] data = new byte[len];
            FileInputStream fis = new FileInputStream(dataFile);
            fis.read(data);

            int j = 0;
            int packet = 0;
            DataPacket dataPacket;
            DataPacket[] result = new DataPacket[len/43];
            while(j<len){

                //Section to read from data to dataPacket
                //region Read data
                dataPacket = new DataPacket();
                dataPacket.time = (0x0ff&(int)data[j++])<<24;
                dataPacket.time += (0x0ff&(int)data[j++])<<16;
                dataPacket.time += (0x0ff&(int)data[j++])<<8;
                dataPacket.time += (0x0ff&(int)data[j++]);


                dataPacket.pressure_center_board = (0x0ff&(int)data[j++])<<8;
                dataPacket.pressure_center_board = (0x0ff&(int)data[j++]);

                dataPacket.strain_rudder = (0x0ff&(int)data[j++])<<8;
                dataPacket.strain_rudder = (0x0ff&(int)data[j++]);

                dataPacket.bat_main = (0x0ff&(int)data[j++])<<8;
                dataPacket.bat_main = (0x0ff&(int)data[j++]);

                dataPacket.bat_center_board = (0x0ff&(int)data[j++])<<8;
                dataPacket.bat_center_board = (0x0ff&(int)data[j++]);

                dataPacket.bat_rudder = (0x0ff&(int)data[j++])<<8;
                dataPacket.bat_rudder = (0x0ff&(int)data[j++]);

                dataPacket.height = (0x0ff&(int)data[j++]);

                dataPacket.magnetometer_x = (0x0ff&(int)data[j++])<<8;
                dataPacket.magnetometer_x = (0x0ff&(int)data[j++]);
                dataPacket.magnetometer_y = (0x0ff&(int)data[j++])<<8;
                dataPacket.magnetometer_y = (0x0ff&(int)data[j++]);
                dataPacket.magnetometer_z = (0x0ff&(int)data[j++])<<8;
                dataPacket.magnetometer_z = (0x0ff&(int)data[j++]);

                dataPacket.accelerometer_x = (0x0ff&(int)data[j++])<<8;
                dataPacket.accelerometer_x = (0x0ff&(int)data[j++]);
                dataPacket.accelerometer_y = (0x0ff&(int)data[j++])<<8;
                dataPacket.accelerometer_y = (0x0ff&(int)data[j++]);
                dataPacket.accelerometer_z = (0x0ff&(int)data[j++])<<8;
                dataPacket.accelerometer_z = (0x0ff&(int)data[j++]);

                dataPacket.gyroscope_x = (0x0ff&(int)data[j++])<<8;
                dataPacket.gyroscope_x = (0x0ff&(int)data[j++]);
                dataPacket.gyroscope_y = (0x0ff&(int)data[j++])<<8;
                dataPacket.gyroscope_y = (0x0ff&(int)data[j++]);
                dataPacket.gyroscope_z = (0x0ff&(int)data[j++])<<8;
                dataPacket.gyroscope_z = (0x0ff&(int)data[j++]);


                byte[] tmp_bytes1 = {data[j++],data[j++],data[j++],data[j++]};
                System.out.println("lat logger read: " + tmp_bytes1.toString());
                dataPacket.latitude = ByteBuffer.wrap(tmp_bytes1).getFloat();
                dataPacket.latdir = ((char)data[j++]);

                byte[] tmp_bytes2 = {data[j++],data[j++],data[j++],data[j++]};
                dataPacket.longitude = ByteBuffer.wrap(tmp_bytes2).getFloat();
                dataPacket.longdir = ((char)data[j++]);

                //endregion

                result[packet++] = dataPacket;
            }

            return result;
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch(IOException e){
            e.printStackTrace();
        }

        return new DataPacket[1];
    }

    // Get data point from start and then length amount of points.
    public DataPacket[] getDataSet(int start, int length) {
        try {
            File dataFile = new File(this.dir + File.pathSeparator + this.session);
            int len = (int) dataFile.length();
            byte[] data = new byte[len];
            FileInputStream fis = new FileInputStream(dataFile);
            fis.read(data);

            int j = start*23;
            int endPoint = (length*23)+(start*23);
            int packet = 0;
            DataPacket dataPacket;
            DataPacket[] result = new DataPacket[len/43];
            while(j<len && j<endPoint){

                //Section to read from data to dataPacket
                //region Read data
                dataPacket = new DataPacket();
                dataPacket.time = (0x0ff&(int)data[j++])<<24;
                dataPacket.time += (0x0ff&(int)data[j++])<<16;
                dataPacket.time += (0x0ff&(int)data[j++])<<8;
                dataPacket.time += (0x0ff&(int)data[j++]);


                dataPacket.pressure_center_board = (0x0ff&(int)data[j++])<<8;
                dataPacket.pressure_center_board = (0x0ff&(int)data[j++]);

                dataPacket.strain_rudder = (0x0ff&(int)data[j++])<<8;
                dataPacket.strain_rudder = (0x0ff&(int)data[j++]);

                dataPacket.bat_main = (0x0ff&(int)data[j++])<<8;
                dataPacket.bat_main = (0x0ff&(int)data[j++]);

                dataPacket.bat_center_board = (0x0ff&(int)data[j++])<<8;
                dataPacket.bat_center_board = (0x0ff&(int)data[j++]);

                dataPacket.bat_rudder = (0x0ff&(int)data[j++])<<8;
                dataPacket.bat_rudder = (0x0ff&(int)data[j++]);

                dataPacket.height = (0x0ff&(int)data[j++]);

                dataPacket.magnetometer_x = (0x0ff&(int)data[j++])<<8;
                dataPacket.magnetometer_x = (0x0ff&(int)data[j++]);
                dataPacket.magnetometer_y = (0x0ff&(int)data[j++])<<8;
                dataPacket.magnetometer_y = (0x0ff&(int)data[j++]);
                dataPacket.magnetometer_z = (0x0ff&(int)data[j++])<<8;
                dataPacket.magnetometer_z = (0x0ff&(int)data[j++]);

                dataPacket.accelerometer_x = (0x0ff&(int)data[j++])<<8;
                dataPacket.accelerometer_x = (0x0ff&(int)data[j++]);
                dataPacket.accelerometer_y = (0x0ff&(int)data[j++])<<8;
                dataPacket.accelerometer_y = (0x0ff&(int)data[j++]);
                dataPacket.accelerometer_z = (0x0ff&(int)data[j++])<<8;
                dataPacket.accelerometer_z = (0x0ff&(int)data[j++]);

                dataPacket.gyroscope_x = (0x0ff&(int)data[j++])<<8;
                dataPacket.gyroscope_x = (0x0ff&(int)data[j++]);
                dataPacket.gyroscope_y = (0x0ff&(int)data[j++])<<8;
                dataPacket.gyroscope_y = (0x0ff&(int)data[j++]);
                dataPacket.gyroscope_z = (0x0ff&(int)data[j++])<<8;
                dataPacket.gyroscope_z = (0x0ff&(int)data[j++]);



                byte[] tmp_bytes1 = {data[j++],data[j++],data[j++],data[j++]};
                dataPacket.latitude = ByteBuffer.wrap(tmp_bytes1).getFloat();
                dataPacket.latdir = ((char)data[j++]);

                byte[] tmp_bytes2 = {data[j++],data[j++],data[j++],data[j++]};
                dataPacket.longitude = ByteBuffer.wrap(tmp_bytes2).getFloat();
                dataPacket.longdir = ((char)data[j++]);


                //endregion

                result[packet++] = dataPacket;
            }

            return result;
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch(IOException e){
            e.printStackTrace();
        }

        return new DataPacket[1];
    }

    public byte[] intToByteArray(int value) {
//        String s = "Int to Byte Array: ";
//        s+= "\n Value: "+value;
//        s+="\n byte: " + (byte)value;
//        s+="\n byte >>>8: " + ((byte)value >> 8);
//        System.out.println(s);
        byte[] b = new byte[4];
        b[3] = (byte) (value >>> 24);
        b[2] = (byte) (value >>> 16);
        b[1] = (byte) (value >>> 8);
        b[0] = (byte) value;
        return b;
    }

    public void clear() {
        PrintWriter file = null;
        try {
            file = new PrintWriter(this.dir + File.pathSeparator + this.session);
            file.print("");
            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}
