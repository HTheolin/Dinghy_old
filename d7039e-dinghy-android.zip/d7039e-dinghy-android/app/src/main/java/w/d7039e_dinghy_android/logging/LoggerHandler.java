package w.d7039e_dinghy_android.logging;

import android.app.Activity;
import android.os.Build;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import w.d7039e_dinghy_android.DataPacket;

/**
 * Created by Mattias on 2016-09-09.
 */
public class LoggerHandler {
    ArrayList<Logger> logs;
    HashMap<String, Integer> loggerMap;
    String applicationPath;
    int currentSelected;

    public LoggerHandler(String applicationPath){


        this.applicationPath = applicationPath+"/"+"dinghy";
        logs = new ArrayList<>();
        loggerMap = new HashMap<String,Integer>();
        currentSelected=0;

        File folder = new File(this.applicationPath);
        folder.mkdirs();
        File[] listOfFiles = folder.listFiles();

        int pos = 0;
        if(listOfFiles != null){
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile()) {
                    logs.add(new Logger(this.applicationPath, listOfFiles[i].getName()));
                    loggerMap.put(listOfFiles[i].getName(),pos++);
                }
            }
        }

    }

    public LoggerHandler(String applicationPath, Activity a){

        String[] perms = {"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"};
        int permsRequestCode = 200;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            a.requestPermissions(perms, permsRequestCode);
            System.out.println("In permission");
        }

        this.applicationPath = applicationPath+"/"+"dinghy";
        logs = new ArrayList<>();
        loggerMap = new HashMap<String,Integer>();
        currentSelected=0;

        File folder = new File(this.applicationPath);
        folder.mkdirs();
        File[] listOfFiles = folder.listFiles();

        int pos = 0;
        if(listOfFiles != null){
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile()) {
                    logs.add(new Logger(this.applicationPath, listOfFiles[i].getName()));
                    loggerMap.put(listOfFiles[i].getName(),pos++);
                }
            }
        }

    }

    // creates a new logger a new log. Will get name of the current date and time.
    public void addNew(){
        Date now = new Date();
        SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yy:HH:mm:SS");
        String filename = DATE_FORMAT.format(now);
        //String filename = "TEST";
        if(!logExist(filename)){
            System.out.println(this.applicationPath + "/" + filename);
            File log = new File(this.applicationPath + "/" + filename);

            try {
                log.createNewFile();
                this.logs.add(new Logger(this.applicationPath, filename));
                currentSelected = this.logs.size()-1;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList<Logger> getLoggers(){
        return logs;
    }

    // get the i;th logger.
    public Logger getLogger(int i){
        return logs.get(i);
    }

    public Logger getLogger(String name){
        if(loggerMap.containsKey(name)){
            return logs.get(loggerMap.get(name));
        }
        return null;
    }

    public List<String> getLoggerNames(){
        List<String> result = new ArrayList<>();
        result.addAll(loggerMap.keySet());
        return result;
    }

    private boolean logExist(String fileName){
        File f = new File(this.applicationPath + "/" + fileName);
        if(f.exists() && !f.isDirectory()) {
            return true;
        }
        return false;
    }

    public boolean hasLogger() {
        return logs.size()!=0;
    }

    public void clearLogger(int i) {
        Logger log = logs.get(i);
        log.clear();
    }

    public void log(DataPacket dp){
        if(logs.size()>currentSelected && currentSelected >= 0){
            //System.out.println("logging.LoggerHandler.java -- Logging dp: " + dp);
            logs.get(currentSelected).log(dp);
        } else{
            System.out.println("logging.LoggerHandler.java -- ERROR: Wongly selected log");
        }
    }

    public void selectLogger(int i){
        currentSelected = i;
    }

    public void selectLogger(String name){
        if(loggerMap.containsKey(name)){
            currentSelected = loggerMap.get(name);
        }
    }

    public DataPacket[] getLogData() {
        Logger log = logs.get(currentSelected);
        System.out.println("Log: " + currentSelected);
        System.out.println("Logs: \n" + loggerMap.toString());
        return log.getDataSet();
    }
}
