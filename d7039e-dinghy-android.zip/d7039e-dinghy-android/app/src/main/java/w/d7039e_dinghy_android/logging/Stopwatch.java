package w.d7039e_dinghy_android.logging;

import java.nio.ByteBuffer;

/**
 * Created by Mattias on 2016-12-01.
 */
public class Stopwatch {
    long _start_time;
    long _stop_time;

    boolean _running;

    public Stopwatch(){
        _start_time = 0;
        _stop_time = 0;
        _running = false;
    }

    public void start(){
        _start_time = System.currentTimeMillis();
        _running = true;
    }


    public long stop(){
        _running=false;
        _stop_time = System.currentTimeMillis();
        return _stop_time-_start_time;
    }

    public long lookup_time(){
        if(!_running){
            return _stop_time-_start_time;
        } else {
            return System.nanoTime()-_start_time;
        }
    }

    public byte[] lookup_time_bytes(){
        byte[] result = new byte[4];
        long time=0;
        long now = System.currentTimeMillis();
        ByteBuffer buffer = ByteBuffer.allocate(8);
        if(!_running){
            time =_stop_time-_start_time;
        } else {
            time= now-_start_time;
        }
        time = time/100;
        buffer.putLong(0, time);
        byte[] bytes = buffer.array();
        result[0] = bytes[4];
        result[1] = bytes[5];
        result[2] = bytes[6];
        result[3] = bytes[7];
        System.out.println("Time: " + time);
        System.out.println("result: [" + result[0] + ", "+ result[1] + ", "+ result[2] + ", "+ result[3] + " ]");
        System.out.println("bytes: [" + bytes[0] + ", "+ bytes[1] + ", "+ bytes[2] + ", "+ bytes[3] +
                                        bytes[4] + ", "+ bytes[5] + ", "+ bytes[6] + ", "+ bytes[7] +
                                    " ]");
        return result;
    }
}