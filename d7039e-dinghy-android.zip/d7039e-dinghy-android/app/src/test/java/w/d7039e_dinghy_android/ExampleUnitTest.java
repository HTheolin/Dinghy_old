package w.d7039e_dinghy_android;

import android.os.Environment;
import android.provider.ContactsContract;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import w.d7039e_dinghy_android.dataprocessor.DataPreProcessor;
import w.d7039e_dinghy_android.logging.LoggerHandler;
import w.d7039e_dinghy_android.logging.Stopwatch;

import static org.junit.Assert.*;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        // DataProcessor
        DataPreProcessor dataProcessor = new DataPreProcessor();
        LoggerHandler loggerHandler = new LoggerHandler("C:/Users/Mattias/Documents/skola");;
        Stopwatch stopwatch = new Stopwatch();
        stopwatch.start();

        byte[] encodedBytes = {109,0
                ,10,10
                ,11,11
                ,10,10
                ,11,11
                ,0x5,0x39
                ,12
                ,10,10,11,11,10,10
                ,10,10,11,11,10,10
                ,10,10,11,11,10,10
                ,1,2,3,4,5,6,7,8,9,10
                ,50,50,50,50,46,50,50,50,50
                ,111
                ,49,49,49,49,49,46,49,49,49,49
                ,121};

        DataPacket dp;
        char messageType = (char) encodedBytes[0];

        assertEquals('m',messageType);

        byte[] _encodedBytesUpper = stopwatch.lookup_time_bytes();
        dataProcessor.addByteArray(_encodedBytesUpper);
        byte[] _encodedBytesLower = Arrays.copyOfRange(encodedBytes,2,encodedBytes.length);
        dataProcessor.addByteArray(_encodedBytesLower);
        dp = dataProcessor.getNextDataPacket();

        assertNotNull(dp);
        System.out.println(dp.toString());
        assertEquals(12,dp.height);
        assertEquals('o',dp.latdir);
        assertEquals('y',dp.longdir);
        assertEquals(1337,dp.bat_rudder);
        assertEquals(2222.2222f,dp.latitude, 0);

        loggerHandler.addNew();
        loggerHandler.log(dp);

        DataPacket[] dps = loggerHandler.getLogData();

        assertEquals(1,dps.length);

        assertEquals(12,dps[0].height);
        assertEquals('o',dps[0].latdir);
        assertEquals('y',dps[0].longdir);
        assertEquals(11111.1111f,dps[0].longitude,0);
        assertEquals(2222.2222f,dps[0].latitude,0);

    }
}